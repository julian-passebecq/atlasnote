# Private PDF library

Import this ZIP locally; do not publish it. Exact PDF bytes, stable Page/Document/private-tree IDs, metadata and rights are retained. Public built-in PDFs, note bodies, related-note references, glossary, personal remarks, ratings, bookmarks and session data are excluded. Use a complete workspace backup for a full restore.

Public built-in notebook/folder context IDs are mapped deterministically into the export namespace to avoid duplicate owners in a fresh default app; atlas-placement-map.json records the original context. The live workspace is never changed.

This standalone snapshot is intended for a fresh workspace or explicit source-ownership review. Existing local/pack IDs must not be duplicated into a second owner. Re-importing an identical library into its destination is idempotent. Advance the pack version for an edited revision.
