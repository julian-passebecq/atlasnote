# PDF Atlas - organized source snapshot

Two supplied PDFs, preserved byte-for-byte. Nothing was fetched from, pushed to or deployed on GitHub or Netlify.

| Catalogue title | Pages | Original filename |
|---|---:|---|
| Apache Spark: 30 concepts | 6 | 1788785230477.pdf |
| PySpark and Pandas: DataFrame guide | 28 | 1788834725906.pdf |

The catalogue titles are concise descriptions based on the rendered covers and document text, not on the old numeric filenames. `printedTitle` records the cover wording. Both documents are English and concern Apache Spark / PySpark; the hierarchy is Data Engineering / Apache Spark. The second includes a Pandas comparison and PySpark code examples. Descriptions are catalogue summaries, not an endorsement or technical audit of the PDF claims.

## Rights

The PDFs are returned only as a reorganization of the user's supplied bytes. Public repository visibility is **not** a redistribution licence. The documents have no populated PDF author/title metadata. Cover credits are recorded conservatively in the manifest. No new rights are granted. Review the right to host these PDFs before publishing. AtlasNote includes metadata and external references only, not these binaries.

## Publishing and pinning (coordinator only)

1. Review rights, then upload this package's contents to the separate `julian-passebecq/pdfatlas` repository. Keep README, manifest and `library/` at its root. The returned app has staging URLs to these organized paths on `main`; they will not resolve until these paths exist.
2. In the AtlasNote source, change only `config/pdfatlas.json` -> `baseUrl` to `https://raw.githubusercontent.com/julian-passebecq/pdfatlas/<exact-40-character-commit>/`.
3. Run `npm run pdfatlas:sync`, then rebuild and run the real-origin and PDF suites. The sync tool validates the metadata contract, generates the same canonical Atlas tree, and refreshes only that generated metadata pack's semantic review hash.
4. Verify the two downloads against the SHA-256 values and byte counts in `atlas-pdf-library.json`. Do not ship staging references as a pinned release.

## Updates and IDs

Keep each `entries[].id` unchanged when renaming/moving a PDF. Keep the explicit category IDs unchanged when renaming categories. For a new PDF revision, recompute the SHA-256, bytes and verified page count, increment its revision and the library version. Do not infer metadata from filenames. Carry forward cover attribution without inventing authors or licences. Copy the updated manifest to AtlasNote's `config/pdfatlas.library.json`, update its base URL and run the sync tool.

## Verify original bytes

Use a SHA-256 utility on the files under `library/`. The hashes and sizes must match the manifest; no compression, OCR or editing was performed. PDFs are never copied into the AtlasNote source/build by the manifest tool.
