import { blankWorkspace } from '../core/workspace.js';
const DB_NAME = 'knowledge-atlas';
const DB_VERSION = 2;
let connection = null;
export function openDatabase() { if (connection)
    return connection; connection = new Promise((resolve, reject) => { const req = indexedDB.open(DB_NAME, DB_VERSION); req.onupgradeneeded = (event) => { const db = req.result; if (event.oldVersion > 0 && event.oldVersion !== 2) {
    req.transaction?.abort();
    reject(Error('Unsupported database upgrade. Export an emergency backup from the previous app before migrating.'));
    return;
} for (const n of ['imports', 'overlays', 'personal', 'assets'])
    if (!db.objectStoreNames.contains(n))
        db.createObjectStore(n); }; req.onsuccess = () => { req.result.onversionchange = () => req.result.close(); resolve(req.result); }; req.onerror = () => reject(req.error); req.onblocked = () => reject(Error('Database upgrade is blocked by another Atlas tab. Close the other tab, then reload.')); }); return connection; }
function request(req) { return new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); }); }
function complete(tx) { return new Promise((resolve, reject) => { tx.oncomplete = () => resolve(); tx.onabort = () => reject(tx.error ?? Error('Storage transaction aborted')); tx.onerror = () => reject(tx.error ?? Error('Storage error')); }); }
export async function loadWorkspace() { const db = await openDatabase(), tx = db.transaction(['imports', 'overlays', 'personal', 'assets'], 'readonly'); const [imports, overlays, personal, assets] = await Promise.all([request(tx.objectStore('imports').getAll()), request(tx.objectStore('overlays').get('active')), request(tx.objectStore('personal').get('active')), request(tx.objectStore('assets').getAll())]); const empty = blankWorkspace(); if (overlays && overlays.schemaVersion !== 2 || personal && personal.schemaVersion !== 2)
    throw Error('Unknown saved-state version. Data has not been reset. Export a raw recovery backup from Settings.'); return { ...empty, imports, overlays: overlays ?? empty.overlays, personal: personal ?? empty.personal, assets }; }
export async function writePersonal(personal) { const db = await openDatabase(), tx = db.transaction('personal', 'readwrite'); const done = complete(tx); tx.objectStore('personal').put(personal, 'active'); await done; }
export async function writeOverlays(overlays) { const db = await openDatabase(), tx = db.transaction('overlays', 'readwrite'); const done = complete(tx); tx.objectStore('overlays').put(overlays, 'active'); await done; }
export async function commitImport(imports, assets, overlays) { const db = await openDatabase(), tx = db.transaction(['imports', 'assets', 'overlays'], 'readwrite'); const done = complete(tx); for (const p of imports)
    tx.objectStore('imports').put(p, p.manifest.id); for (const a of assets)
    tx.objectStore('assets').put(a, a.key); tx.objectStore('overlays').put(overlays, 'active'); await done; }
export async function restoreWorkspace(ws) { const db = await openDatabase(), tx = db.transaction(['imports', 'overlays', 'personal', 'assets'], 'readwrite'); const done = complete(tx); for (const n of ['imports', 'overlays', 'personal', 'assets'])
    tx.objectStore(n).clear(); for (const p of ws.imports)
    tx.objectStore('imports').put(p, p.manifest.id); for (const a of ws.assets)
    tx.objectStore('assets').put(a, a.key); tx.objectStore('overlays').put(ws.overlays, 'active'); tx.objectStore('personal').put(ws.personal, 'active'); await done; }
export async function rawRecovery() { const db = await openDatabase(), tx = db.transaction(['imports', 'overlays', 'personal', 'assets'], 'readonly'); return Object.fromEntries(await Promise.all(['imports', 'overlays', 'personal', 'assets'].map(async (n) => [n, await request(tx.objectStore(n).getAll())]))); }
export class WorkspaceStore {
    state = blankWorkspace();
    error = '';
    saving = 0;
    listeners = new Set();
    queue = Promise.resolve();
    subscribe = (fn) => { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; };
    getSnapshot = () => this.state;
    emit() { this.listeners.forEach(f => f()); }
    setLoaded(ws) { this.state = ws; this.emit(); }
    fail = (e) => { this.error = `Changes could not be saved: ${e?.message ?? e}. Keep this tab open. Free browser storage, then retry, or download an emergency backup.`; this.state = { ...this.state }; this.emit(); };
    enqueue(fn) { this.saving++; this.state = { ...this.state }; this.emit(); const result = this.queue.then(fn); this.queue = result.catch(this.fail).finally(() => { this.saving--; this.state = { ...this.state }; this.emit(); }); return result; }
    personal(fn) { const p = structuredClone(this.state.personal); fn(p); this.state = { ...this.state, personal: p, generation: this.state.generation + 1 }; this.emit(); this.enqueue(() => writePersonal(p)); }
    overlays(fn) { const o = structuredClone(this.state.overlays); fn(o); this.state = { ...this.state, overlays: o, generation: this.state.generation + 1 }; this.emit(); return this.enqueue(() => writeOverlays(o)); }
    async importPacks(imports, assets, overlays) { await this.flush(); await commitImport(imports, assets, overlays); const byPack = new Map(this.state.imports.map(p => [p.manifest.id, p])); imports.forEach(p => byPack.set(p.manifest.id, p)); const byAsset = new Map(this.state.assets.map(a => [a.key, a])); assets.forEach(a => byAsset.set(a.key, a)); this.state = { ...this.state, imports: [...byPack.values()], assets: [...byAsset.values()], overlays, generation: this.state.generation + 1 }; this.emit(); }
    async restore(ws) { await this.flush(); await restoreWorkspace(ws); this.state = { ...ws, generation: this.state.generation + 1 }; this.error = ''; this.emit(); }
    async addAsset(asset) { await this.flush(); const db = await openDatabase(), tx = db.transaction('assets', 'readwrite'), done = complete(tx); tx.objectStore('assets').put(asset, asset.key); await done; this.state = { ...this.state, assets: [...this.state.assets.filter(a => a.key !== asset.key), asset] }; this.emit(); }
    async flush() { await this.queue; }
    async retry() { await restoreWorkspace(this.state); this.error = ''; this.state = { ...this.state }; this.emit(); }
}
export const store = new WorkspaceStore();
