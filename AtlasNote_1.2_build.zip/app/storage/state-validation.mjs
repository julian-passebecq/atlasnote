import { inspectObject, ID, safeUrl, validateSchema } from '../core/validation.mjs';
/** Validate restored personal state before any IndexedDB write. Never repair by dropping fields. */
export function validateState(ws, schemas) {
    inspectObject(ws);
    const fail = m => { throw Error('Invalid saved workspace: ' + m); };
    const obj = (x, n) => { if (!x || typeof x !== 'object' || Array.isArray(x))
        fail(n); };
    const str = (x, n, max = 1000000) => { if (typeof x !== 'string' || x.length > max)
        fail(n); };
    const num = (x, n, lo = 0, hi = Number.MAX_SAFE_INTEGER) => { if (!Number.isFinite(x) || x < lo || x > hi)
        fail(n); };
    const bool = (x, n) => { if (typeof x !== 'boolean')
        fail(n); };
    const id = (x, n) => { if (typeof x !== 'string' || !ID.test(x))
        fail(n); };
    const arr = (x, n, max = 100000) => { if (!Array.isArray(x) || x.length > max)
        fail(n); };
    const anchor = a => { if (a === undefined)
        return; obj(a, 'anchor'); if (a.blockId !== undefined)
        id(a.blockId, 'anchor block'); if (a.offset !== undefined)
        num(a.offset, 'anchor offset'); if (a.unit !== undefined)
        str(a.unit, 'source unit', 256); if (a.viewportOffset !== undefined)
        num(a.viewportOffset, 'anchor viewport offset', -1000000, 1000000); if (a.atStart !== undefined)
        bool(a.atStart, 'anchor start'); if (a.pdfPage !== undefined)
        num(a.pdfPage, 'physical PDF page', 1, 1000000); if (a.pdfRevision !== undefined)
        str(a.pdfRevision, 'PDF revision', 256); };
    const p = ws?.personal, o = ws?.overlays;
    obj(p, 'personal');
    obj(o, 'overlays');
    if (p.schemaVersion !== 2 || o.schemaVersion !== 2)
        fail('schema version');
    obj(p.notes, 'notes');
    for (const [key, n] of Object.entries(p.notes)) {
        str(key, 'remark key', 600);
        obj(n, 'remark');
        str(n.text, 'remark text');
        id(n.pageId, 'remark page');
        num(n.updatedAt, 'remark timestamp');
        anchor(n.anchor);
        if (n.revision !== undefined)
            str(n.revision, 'remark revision', 256);
    }
    obj(p.ratings, 'ratings');
    for (const [key, value] of Object.entries(p.ratings)) {
        id(key, 'rated page');
        if (!['gray', 'red', 'orange', 'green'].includes(value))
            fail('rating');
    }
    arr(p.bookmarks, 'bookmarks');
    const bookmarkIds = new Set();
    for (const b of p.bookmarks) {
        id(b.id, 'bookmark ID');
        if (bookmarkIds.has(b.id))
            fail('duplicate bookmark');
        bookmarkIds.add(b.id);
        id(b.pageId, 'bookmark page');
        str(b.title, 'bookmark title', 10000);
        num(b.createdAt, 'bookmark timestamp');
        anchor(b.anchor);
    }
    const s = p.session;
    obj(s, 'session');
    arr(s.panes, 'panes', 2);
    if (!s.panes.length)
        fail('no pane');
    const paneIds = new Set(), viewIds = new Set();
    for (const pane of s.panes) {
        id(pane.id, 'pane ID');
        if (paneIds.has(pane.id))
            fail('duplicate pane');
        paneIds.add(pane.id);
        arr(pane.views, 'views', 5);
        for (const v of pane.views) {
            id(v.id, 'view ID');
            if (viewIds.has(v.id))
                fail('duplicate view');
            viewIds.add(v.id);
            arr(v.history, 'history', 10000);
            num(v.cursor, 'history cursor', 0, Math.max(0, v.history.length - 1));
            if (!Number.isInteger(v.cursor))
                fail('fractional history cursor');
            bool(v.english, 'English visibility');
            for (const key of ['collapsed', 'revealed']) {
                obj(v[key], key);
                for (const [bid, state] of Object.entries(v[key])) {
                    id(bid, 'disclosure block');
                    bool(state, 'disclosure');
                }
            }
            for (const l of v.history) {
                id(l.pageId, 'history page');
                if (l.collectionId !== undefined) {
                    id(l.collectionId, 'collection ID');
                    if (l.pageId !== l.collectionId)
                        fail('collection navigation identity');
                }
                if (!['continuous', 'book', 'parallel'].includes(l.presentation))
                    fail('presentation');
                if (!['single', 'continuous', 'spread'].includes(l.pdfMode))
                    fail('PDF mode');
                num(l.pdfPage, 'PDF page', 1, 1000000);
                num(l.zoom, 'zoom', 0.1, 10);
                if (![0, 90, 180, 270].includes(l.rotation))
                    fail('rotation');
                bool(l.cover, 'cover');
                anchor(l.anchor);
                if (l.scroll !== undefined)
                    num(l.scroll, 'scroll');
            }
        }
        if (pane.views.length && !pane.views.some(v => v.id === pane.active))
            fail('active view missing');
        if (!pane.views.length && pane.active !== '')
            fail('empty active view');
    }
    if (!paneIds.has(s.activePane))
        fail('active pane missing');
    num(s.ratio, 'split ratio', 28, 72);
    num(s.fontSize, 'font size', 14, 22);
    if (!['home', 'reader', 'bookmarks'].includes(s.screen))
        fail('screen');
    if (!['fluent', 'neutral', 'academic', 'lavender', 'slate'].includes(s.theme))
        fail('theme');
    if (s.libraryMode !== undefined && !['notes', 'pdfs'].includes(s.libraryMode))
        fail('library mode');
    for (const key of ['leftOpen', 'rightOpen', 'focus', 'showFlags'])
        bool(s[key], key);
    arr(s.expanded, 'expanded IDs');
    s.expanded.forEach(x => id(x, 'expanded ID'));
    obj(o.pages, 'page overlays');
    arr(o.projects, 'local projects');
    obj(o.projectPrefs, 'project preferences');
    arr(o.operations, 'structural operations');
    arr(o.archived, 'archives');
    o.archived.forEach(x => id(x, 'archived ID'));
    arr(o.documents, 'local documents');
    if (o.groups !== null)
        arr(o.groups, 'groups');
    for (const [key, edit] of Object.entries(o.pages)) {
        obj(edit, 'page overlay');
        if (edit.page?.id !== key)
            fail('overlay ID mismatch');
        validateSchema({ schemaVersion: 2, title: 'Local overlay', projects: [], pages: [edit.page], glossary: [], groups: [] }, schemas.v2, 'local overlay');
        if (edit.baseHash !== undefined && !/^[a-f0-9]{64}$/.test(edit.baseHash))
            fail('overlay base hash');
    }
    validateSchema({ schemaVersion: 2, title: 'Local tree', projects: o.projects, pages: [], glossary: [], groups: o.groups ?? [] }, schemas.v2, 'local tree');
    for (const [key, pref] of Object.entries(o.projectPrefs)) {
        id(key, 'project preference');
        obj(pref, 'project preference');
        for (const k of ['title', 'description', 'icon'])
            if (pref[k] !== undefined)
                str(pref[k], k, 10000);
        if (pref.hidden !== undefined)
            bool(pref.hidden, 'hidden');
        if (pref.order !== undefined)
            num(pref.order, 'order', -100000, 100000);
    }
    for (const op of o.operations) {
        obj(op, 'operation');
        if (!['add', 'move', 'rename', 'order'].includes(op.kind))
            fail('operation kind');
        id(op.nodeId, 'operation ID');
        for (const k of ['projectId', 'parentId'])
            if (op[k])
                id(op[k], k);
        if (op.kind === 'rename')
            str(op.title, 'node title', 10000);
        if (op.kind === 'order')
            num(op.delta, 'order delta', -10000, 10000);
        if (['add', 'move'].includes(op.kind))
            id(op.projectId, 'destination project');
        if (op.kind === 'add') {
            if (op.node?.id !== op.nodeId)
                fail('added node ID');
            validateSchema({ schemaVersion: 2, title: 'Node', projects: [{ id: 'project.validation', title: 'Validation', icon: 'book', description: '', nodes: [op.node] }], pages: [], glossary: [], groups: [] }, schemas.v2, 'local node');
        }
    }
    for (const d of o.documents) {
        id(d.id, 'local document');
        id(d.pageId, 'document page');
        str(d.title, 'document title', 10000);
        if (!['public', 'private', 'unreviewed'].includes(d.visibility))
            fail('document visibility');
        obj(d.rights, 'document rights');
        str(d.rights.attribution, 'attribution', 10000);
        obj(d.source, 'document source');
        if (!['local', 'library-file', 'pack-file', 'https', 'external-link'].includes(d.source.kind))
            fail('document source kind');
        if (d.source.url && !safeUrl(d.source.url))
            fail('document URL');
        if (d.sha256 && !/^[a-f0-9]{64}$/.test(d.sha256))
            fail('document hash');
        if (d.assetKey !== undefined)
            str(d.assetKey, 'document asset key', 600);
    }
    return true;
}
