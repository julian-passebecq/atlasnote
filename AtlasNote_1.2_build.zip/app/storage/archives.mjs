import { validateState } from './state-validation.mjs';
import { selectPacks } from '../core/packs.mjs';
import { safePath, sha256, stable, inspectObject, validateRelations, validateSchema, assertSafeAsset } from '../core/validation.mjs';
const MAX_FILES = 6000, MAX_TOTAL = 250 * 1024 * 1024, MAX_RATIO = 500, MAX_ENTRY = 25 * 1024 * 1024;
/** Parse central directory before JSZip decompresses anything. ZIP64 and symlinks are deliberately unsupported. */
export function inspectZip(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let end = -1;
    for (let p = bytes.length - 22; p >= Math.max(0, bytes.length - 65557); p--)
        if (view.getUint32(p, true) === 0x06054b50) {
            end = p;
            break;
        }
    if (end < 0)
        throw Error('Not a ZIP archive');
    if (view.getUint16(end + 4, true) || view.getUint16(end + 6, true))
        throw Error('Split ZIP archives are not supported');
    const count = view.getUint16(end + 10, true), offset = view.getUint32(end + 16, true);
    if (count === 65535 || offset === 0xffffffff)
        throw Error('ZIP64 is not supported');
    if (count > MAX_FILES)
        throw Error('ZIP contains too many files');
    let pos = offset, total = 0;
    const entries = [], names = new Set();
    const decoder = new TextDecoder('utf-8', { fatal: true });
    for (let i = 0; i < count; i++) {
        if (pos + 46 > bytes.length || view.getUint32(pos, true) !== 0x02014b50)
            throw Error('Malformed ZIP directory');
        const flags = view.getUint16(pos + 8, true), method = view.getUint16(pos + 10, true), compressed = view.getUint32(pos + 20, true), size = view.getUint32(pos + 24, true), len = view.getUint16(pos + 28, true), extra = view.getUint16(pos + 30, true), comment = view.getUint16(pos + 32, true), attrs = view.getUint32(pos + 38, true);
        const original = decoder.decode(bytes.slice(pos + 46, pos + 46 + len));
        pos += 46 + len + extra + comment;
        if (flags & 1)
            throw Error('Encrypted ZIP is not supported');
        if (![0, 8].includes(method))
            throw Error('Unsupported ZIP compression');
        if ((attrs >>> 16 & 0xf000) === 0xa000)
            throw Error('ZIP symlink rejected');
        const name = original.endsWith('/') ? original.slice(0, -1) : original;
        if (name)
            safePath(name);
        if (names.has(name.toLowerCase()))
            throw Error('Duplicate/case-colliding ZIP path ' + name);
        names.add(name.toLowerCase());
        if (original.endsWith('/'))
            continue;
        if (size > MAX_ENTRY || size / (compressed || 1) > MAX_RATIO || (total += size) > MAX_TOTAL)
            throw Error('ZIP expansion safety limit exceeded');
        entries.push({ name: original, size });
    }
    if (pos > end)
        throw Error('ZIP directory overlaps footer');
    return { entries, total };
}
async function zipClass() { if (typeof window !== 'undefined' && window.JSZip)
    return window.JSZip; return (await import('jszip')).default; }
export async function unzipBounded(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(await input.arrayBuffer());
    if (bytes.length > MAX_TOTAL)
        throw Error('ZIP exceeds 250 MB');
    const meta = inspectZip(bytes), Zip = await zipClass(), zip = await Zip.loadAsync(bytes, { checkCRC32: true, createFolders: false });
    const files = new Map();
    for (const { name, size } of meta.entries) {
        if (!/\.(json|md|txt|pdf|svg|png|jpg|jpeg|webp)$/i.test(name))
            throw Error('Quarantined unsupported file: ' + name + '. Notebook files and executable sources are never executed or guessed.');
        const entry = zip.file(name);
        if (!entry || entry.unsafeOriginalName && entry.unsafeOriginalName !== name)
            throw Error('ZIP path normalization rejected');
        const value = await entry.async('uint8array');
        if (value.length !== size)
            throw Error('ZIP byte count mismatch');
        files.set(name, value);
    }
    const manifests = [...files.keys()].filter(p => /(^|\/)atlas-transfer\.json$/.test(p));
    let transfer = null;
    if (manifests.length > 1)
        throw Error('Multiple transfer manifests');
    if (manifests.length) {
        const path = manifests[0], prefix = path.slice(0, -'atlas-transfer.json'.length);
        transfer = JSON.parse(new TextDecoder().decode(files.get(path)));
        inspectObject(transfer);
        if (transfer.format !== 'atlas-transfer' || transfer.schemaVersion !== 1)
            throw Error('Unknown transfer format');
        for (const [p, hash] of Object.entries(transfer.sha256)) {
            safePath(p);
            const b = files.get(prefix + p);
            if (!b || await sha256(b) !== hash)
                throw Error('Transfer checksum mismatch: ' + p);
        }
        for (const p of files.keys())
            if (p !== path && !Object.hasOwn(transfer.sha256, p.slice(prefix.length)))
                throw Error('Unlisted transfer file: ' + p);
    }
    return { files, transfer, bytes: meta.total };
}
export async function zipFiles(files, kind) { const Zip = await zipClass(), zip = new Zip(), hashes = {}; for (const [name, value] of files) {
    safePath(name);
    const bytes = typeof value === 'string' ? new TextEncoder().encode(value) : value;
    zip.file(name, bytes);
    hashes[name] = await sha256(bytes);
} zip.file('atlas-transfer.json', JSON.stringify({ format: 'atlas-transfer', schemaVersion: 1, kind, createdAt: new Date().toISOString(), sha256: hashes }, null, 2)); return zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 6 } }); }
export function download(bytes, name, type = 'application/zip') { const blob = bytes instanceof Blob ? bytes : new Blob([bytes], { type }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 30000); }
export async function makeBackup(ws, built, resolveAsset) {
    const packs = new Map(selectPacks(built.packs, ws.imports).packs.map(p => [p.manifest.id, p]));
    const files = new Map(), allAssets = new Map(ws.assets.map(a => [a.key, a]));
    // Imported packs and local PDFs are dependencies too, not just built-in assets.
    const required = new Set([...packs.values()].flatMap(p => p.assetKeys ?? []));
    for (const doc of [...packs.values()].flatMap(p => p.documents ?? []).concat(ws.overlays.documents ?? []))
        if (doc.assetKey)
            required.add(doc.assetKey);
    for (const key of required) {
        if (!allAssets.has(key)) {
            const asset = await resolveAsset(key);
            if (asset)
                allAssets.set(key, asset);
            else
                throw Error('Backup cancelled: local byte dependency unavailable: ' + key);
        }
        const asset = allAssets.get(key);
        if (!(asset.bytes instanceof Uint8Array) || await sha256(asset.bytes) !== asset.sha256)
            throw Error('Backup cancelled: corrupt attachment: ' + key);
    }
    // Fail before offering a ZIP if any manifest or document points at different bytes.
    for (const pack of packs.values())
        for (const m of pack.manifest.assets ?? []) {
            const key = pack.manifest.id + '@' + pack.manifest.version + '/' + m.path, a = allAssets.get(key);
            if (!a || a.sha256 !== m.sha256 || a.mediaType !== m.mediaType)
                throw Error('Backup cancelled: manifest attachment mismatch: ' + key);
        }
    for (const doc of [...packs.values()].flatMap(p => p.documents ?? []).concat(ws.overlays.documents ?? []))
        if (doc.assetKey) {
            const a = allAssets.get(doc.assetKey);
            if (!a || a.sha256 !== doc.sha256 || a.bytes.length !== doc.bytes)
                throw Error('Backup cancelled: PDF attachment mismatch: ' + doc.id);
        }
    const metadata = [];
    let n = 0;
    for (const asset of allAssets.values()) {
        if (!(asset.bytes instanceof Uint8Array) || await sha256(asset.bytes) !== asset.sha256)
            throw Error('Backup cancelled: corrupt attachment: ' + asset.key);
        const path = 'assets/' + String(n++).padStart(4, '0') + '.' + asset.key.split('.').pop();
        files.set(path, asset.bytes);
        metadata.push({ key: asset.key, sha256: asset.sha256, mediaType: asset.mediaType, path });
    }
    const external = [];
    for (const p of packs.values())
        for (const page of p.pages) {
            const scan = bs => bs.forEach(b => { if (b.src && /^https?:/.test(b.src))
                external.push({ pageId: page.id, url: b.src, reason: 'Remote reference not downloaded' }); if (b.children)
                scan(b.children); });
            scan(page.blocks);
        }
    const snapshot = { format: 'atlas-workspace-backup', schemaVersion: 2, builtRelease: built.releaseId, workspace: { ...ws, imports: [...packs.values()], assets: [] }, assetIndex: metadata, retainedImportedRevisions: ws.imports, externalDependencies: external };
    files.set('backup.json', JSON.stringify(snapshot));
    return { bytes: await zipFiles(files, 'backup'), external, snapshot };
}
export async function readBackup(files, schemas) {
    const key = [...files.keys()].find(p => /(^|\/)backup\.json$/.test(p));
    if (!key)
        throw Error('No backup.json');
    const root = key.slice(0, -'backup.json'.length), data = JSON.parse(new TextDecoder().decode(files.get(key)));
    inspectObject(data);
    if (data.format !== 'atlas-workspace-backup' || data.schemaVersion !== 2)
        throw Error('Unsupported backup. No data has been changed.');
    const ws = data.workspace;
    validateState(ws, schemas);
    if (ws?.personal?.schemaVersion !== 2 || ws?.overlays?.schemaVersion !== 2 || !Array.isArray(ws.imports) || !Array.isArray(ws.personal.session?.panes) || ws.personal.session.panes.length > 2)
        throw Error('Invalid backup state');
    for (const p of ws.imports) {
        if (!Array.isArray(p.assetKeys) || !Array.isArray(p.documents))
            throw Error('Invalid backup pack assets/documents');
        const docs = p.documents.map(({ packId, assetKey, ...d }) => d);
        validateSchema({ format: 'atlas-document-index', schemaVersion: 1, packId: p.manifest.id, version: p.manifest.version, documents: docs }, schemas.documents, 'backup documents');
        validateSchema(p.manifest, schemas.manifest, 'backup manifest');
        validateSchema({ schemaVersion: 2, title: p.manifest.title, projects: p.projects, pages: p.pages, glossary: p.glossary, groups: [] }, schemas.v2, 'backup pack');
        const hash = await sha256(stable({ manifest: p.manifest, projects: p.projects, pages: p.pages, glossary: p.glossary, documents: p.documents }));
        if (hash !== p.hash)
            throw Error('Backup pack semantic hash mismatch');
    }
    validateRelations(ws.imports);
    for (const edit of Object.values(ws.overlays.pages)) {
        validateSchema({ schemaVersion: 2, title: 'local', projects: [], pages: [edit.page], glossary: [], groups: [] }, schemas.v2, 'local overlay');
    }
    if (!Array.isArray(data.assetIndex))
        throw Error('Missing backup asset index');
    const assetKeys = new Set();
    const assets = [];
    for (const m of data.assetIndex) {
        if (typeof m.key !== 'string' || assetKeys.has(m.key))
            throw Error('Duplicate/invalid backup asset key');
        assetKeys.add(m.key);
        safePath(m.path);
        const b = files.get(root + m.path);
        if (!b || await sha256(b) !== m.sha256)
            throw Error('Missing/corrupt backup attachment');
        assertSafeAsset(m.path, b, m.mediaType);
        assets.push({ ...m, bytes: b });
    }
    const index = new Map(assets.map(a => [a.key, a]));
    for (const p of ws.imports) {
        for (const key of p.assetKeys)
            if (!index.has(key))
                throw Error('Backup missing pack asset: ' + key);
        for (const m of p.manifest.assets) {
            const a = index.get(p.manifest.id + '@' + p.manifest.version + '/' + m.path);
            if (!a || a.sha256 !== m.sha256 || a.mediaType !== m.mediaType)
                throw Error('Backup manifest asset mismatch: ' + m.path);
        }
        for (const d of p.documents)
            if (d.source.kind === 'pack-file') {
                const expected = p.manifest.id + '@' + p.manifest.version + '/' + d.source.path, a = index.get(expected);
                if (d.assetKey !== expected || !a || a.sha256 !== d.sha256 || a.bytes.length !== d.bytes)
                    throw Error('Backup PDF revision mismatch: ' + d.id);
            }
    }
    for (const d of ws.overlays.documents ?? [])
        if (d.assetKey) {
            const a = index.get(d.assetKey);
            if (!a)
                throw Error('Backup missing local PDF: ' + d.id);
            if (a.sha256 !== d.sha256 || a.bytes.length !== d.bytes)
                throw Error('Backup local PDF revision mismatch: ' + d.id);
        }
    for (const [key, note] of Object.entries(ws.personal.notes))
        if (typeof note.text !== 'string' || typeof note.pageId !== 'string' || note.text.length > 1000000)
            throw Error('Invalid saved remark ' + key);
    return { ...data, workspace: { ...ws, assets } };
}
