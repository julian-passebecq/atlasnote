export const FLAG_LABELS = { gray: 'Not rated', red: 'Revisit', orange: 'Learning', green: 'Understood' };
export const THEME_LABELS = { fluent: 'Fluent Blue', neutral: 'Neutral/Sage', academic: 'Academic Paper', lavender: 'Soft Lavender', slate: 'Dark Slate' };
