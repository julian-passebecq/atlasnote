import { zipFiles } from '../storage/archives.mjs';
import { stable, sha256, validateRelations, pageLinks } from './validation.mjs';
/** Repository-shaped, explicitly PRIVATE snapshot. Publication still requires review.
 * Local reading flags/remarks are not mixed into canonical page bodies. */
export async function exportRepositoryWorkspace(catalogue, workspace, resolveAsset) {
    const localId = 'atlas.local-additions', packs = structuredClone(catalogue.packs), extraPages = catalogue.pages.filter(p => catalogue.owners[p.id] === 'local'), existing = packs.find(p => p.manifest.id === localId);
    if (extraPages.length || workspace.overlays.projects.length || workspace.overlays.documents.length) {
        if (!existing)
            packs.push({ manifest: { format: 'atlas-content-pack', schemaVersion: 1, payloadSchema: 'atlas.bundle@2', id: localId, version: '1.0.0', title: 'Local additions', visibility: 'private', files: { projects: 'projects.json', pages: 'pages', glossary: 'glossary.json' }, requires: [], assets: [], provenance: { kind: 'local-user-content' } }, projects: [], pages: [], glossary: [], documents: [], assetKeys: [], migration: [] });
    }
    const owner = { ...catalogue.owners };
    extraPages.forEach(p => owner[p.id] = localId);
    workspace.overlays.projects.forEach(p => owner[p.id] = localId);
    const files = new Map(), assetData = new Map();
    const json = (name, value) => files.set(name, JSON.stringify(value, null, 2) + '\n');
    for (const p of packs) {
        const version = p.manifest.version.split('.').map(Number);
        p.manifest.version = [version[0], version[1], version[2] + 1].join('.');
        p.manifest.visibility = 'private';
        p.manifest.payloadSchema = 'atlas.bundle@2';
        p.projects = catalogue.projects.filter(x => owner[x.id] === p.manifest.id).map(({ id, title, icon, description, nodes }) => ({ id, title, icon, description, nodes }));
        p.pages = catalogue.pages.filter(x => owner[x.id] === p.manifest.id);
        if (p.manifest.id === localId)
            p.documents = [...p.documents, ...workspace.overlays.documents];
        const assetRows = [];
        for (const a of p.manifest.assets) {
            const original = catalogue.packs.find(x => x.manifest.id === p.manifest.id), key = original.manifest.id + '@' + original.manifest.version + '/' + a.path, asset = await resolveAsset(key);
            if (!asset)
                throw Error('Missing attachment ' + key);
            assetData.set(p.manifest.id + '/' + a.path, asset.bytes);
            assetRows.push(a);
        }
        p.documents = p.documents.map(d => { const { packId, assetKey, ...record } = d; return record; });
        if (p.manifest.id === localId) {
            for (const original of workspace.overlays.documents) {
                const a = await resolveAsset(original.assetKey);
                if (!a)
                    throw Error('Missing local PDF bytes');
                const path = 'assets/' + a.sha256 + '.pdf';
                if (!assetRows.some(r => r.path === path))
                    assetRows.push({ path, mediaType: a.mediaType, sha256: a.sha256 });
                assetData.set(p.manifest.id + '/' + path, a.bytes);
                const d = p.documents.find(d => d.id === original.id);
                d.source = { kind: 'pack-file', path };
            }
        }
        p.manifest.assets = assetRows;
    }
    // Explicit dependencies based on stable ownership, not display paths.
    for (const p of packs) {
        const dependencies = new Set(p.manifest.requires.map(d => d.id));
        const add = id => { const o = owner[id]; if (o && o !== p.manifest.id)
            dependencies.add(o); };
        const walk = ns => ns.forEach(n => { if (n.pageId)
            add(n.pageId); if (n.children)
            walk(n.children); });
        p.projects.forEach(project => walk(project.nodes));
        for (const page of p.pages) {
            pageLinks(page).forEach(add);
            page.terms.forEach(add);
        }
        p.glossary.forEach(t => t.pageIds.forEach(add));
        p.manifest.requires = [...dependencies].filter(id => id !== p.manifest.id).map(id => ({ id, version: packs.find(x => x.manifest.id === id)?.manifest.version ?? '1.0.0' }));
    }
    validateRelations(packs);
    for (const p of packs) {
        const base = 'packs/' + p.manifest.id + '/';
        json(base + 'atlas-pack.json', p.manifest);
        json(base + p.manifest.files.projects, p.projects);
        json(base + p.manifest.files.glossary, p.glossary);
        for (const page of p.pages)
            json(base + p.manifest.files.pages + '/' + page.id + '.json', page);
        if (p.documents.length)
            json(base + 'atlas-documents.json', { format: 'atlas-document-index', schemaVersion: 1, packId: p.manifest.id, version: p.manifest.version, documents: p.documents });
        if (p.migration?.length)
            json(base + 'block-migration.json', { schemaVersion: 1, assignments: p.migration });
        for (const a of p.manifest.assets)
            files.set(base + a.path, assetData.get(p.manifest.id + '/' + a.path));
    }
    json('workspace.json', { format: 'atlas-workspace', schemaVersion: 1, title: 'Private local workspace export', packsDirectory: 'packs', disabledPackIds: [], groups: catalogue.groups });
    files.set('README.md', '# Private content workspace\n\nThis is a repository-shaped content snapshot, not the application source. All packs are deliberately private. Do not put this archive in a public repository. Pack versions were advanced; stable IDs and relationships are retained. The public compiler rejects these packs until an explicit rights/privacy review. Personal remarks, learning flags, bookmarks, archives and view state are not part of these canonical packs; use a complete workspace backup for them.\n');
    return { bytes: await zipFiles(files, 'private-repository-workspace'), packCount: packs.length, pageCount: catalogue.pages.length };
}
