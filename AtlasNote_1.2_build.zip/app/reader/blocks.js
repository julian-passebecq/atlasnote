import React, { useEffect, useRef, useState } from '../vendor/react.mjs';
import { Inline, parseMarkdown } from './markdown.js';
import { Icon } from '../components/Icon.js';
import { safeUrl } from '../core/validation.mjs';
let mermaidPromise = null;
let mermaidQueue = Promise.resolve();
export function Mermaid({ code, onReady }) { const [svg, setSvg] = useState(''), [error, setError] = useState(''); const id = useRef('mermaid-' + crypto.randomUUID().replaceAll('-', '')); useEffect(() => { let alive = true; if (!mermaidPromise)
    mermaidPromise = import('../vendor/mermaid-loader.mjs').then(m => { m.default.initialize({ startOnLoad: false, securityLevel: 'strict', suppressErrorRendering: true, theme: 'neutral', flowchart: { htmlLabels: false }, fontFamily: 'Arial, sans-serif', maxTextSize: 50000 }); return m.default; }); mermaidQueue = mermaidQueue.catch(() => { }).then(async () => { try {
    if (code.length > 50000)
        throw Error('Diagram exceeds the size limit');
    if (/%%\{\s*(init|config)\s*:/i.test(code))
        throw Error('Embedded renderer configuration is not allowed');
    const m = await mermaidPromise;
    const r = await m.render(id.current, code);
    if (alive) {
        setSvg(r.svg);
        setTimeout(() => onReady?.(), 30);
    }
}
catch (e) {
    if (alive)
        setError(e.message);
} }); return () => { alive = false; }; }, [code]); return error ? React.createElement("div", { className: "render-error" },
    React.createElement("strong", null, "Diagram could not be rendered"),
    React.createElement("p", null, error),
    React.createElement("pre", null, code)) : svg ? React.createElement("div", { className: "mermaid-figure", "data-mermaid-ready": "true", dangerouslySetInnerHTML: { __html: svg } }) : React.createElement("div", { className: "diagram-loading" }, "Rendering diagram..."); }
export function Code({ code, language, title, id }) { const lang = String(language || 'text').toLowerCase(), grammar = window.Prism?.languages[lang]; return React.createElement("div", { className: "code-block" },
    React.createElement("div", { className: "code-header" },
        React.createElement("span", null, title || lang),
        React.createElement("button", { "data-action": "copy-code", "data-block": id, "data-snippet": code, title: "Copy whole code snippet" },
            React.createElement(Icon, { name: "copy", size: 14 }),
            " Copy")),
    React.createElement("pre", null,
        React.createElement("code", { className: 'language-' + lang }, String(code).split('\n').map((line, i) => grammar ? React.createElement("span", { className: "code-line", key: i, dangerouslySetInnerHTML: { __html: window.Prism.highlight(line || ' ', grammar, lang) } }) : React.createElement("span", { className: "code-line", key: i }, line || ' '))))); }
function Table({ columns, rows }) { return React.createElement("div", { className: "table-wrap" },
    React.createElement("table", null,
        React.createElement("thead", null,
            React.createElement("tr", null, columns.map((c, i) => React.createElement("th", { key: i },
                React.createElement(Inline, { text: c }))))),
        React.createElement("tbody", null, rows.map((r, i) => React.createElement("tr", { key: i }, r.map((c, j) => React.createElement("td", { key: j },
            React.createElement(Inline, { text: c })))))))); }
function List({ items, ordered = false }) { const Tag = ordered ? 'ol' : 'ul'; return React.createElement(Tag, null, items.map((s, i) => React.createElement("li", { key: i },
    React.createElement(Inline, { text: s })))); }
export function Source({ source }) { return React.createElement("span", { className: "provenance" },
    "Source: ",
    source?.url && safeUrl(source.url) ? React.createElement("a", { href: source.url, target: "_blank", rel: "noopener noreferrer" }, source.title) : source?.title,
    source?.publisher ? ' - ' + source.publisher : '',
    source?.note ? ' - ' + source.note : ''); }
function ImageFigure({ block, url, onReady }) { const remote = safeUrl(block.src), [load, setLoad] = useState(!remote), [failed, setFailed] = useState(false); return React.createElement("figure", null,
    remote && !load ? React.createElement("div", { className: "external-placeholder" },
        React.createElement(Icon, { name: "link" }),
        React.createElement("p", null, "Official/reference image hosted externally. Loading contacts the source website."),
        React.createElement("button", { onClick: () => setLoad(true), "data-action": "load-image", "data-block": block.id }, "Load reference image")) : failed || !url ? React.createElement("div", { className: "render-error" }, "Image unavailable. The source reference is retained.") : React.createElement("img", { src: url, alt: block.alt ?? block.caption, loading: "eager", referrerPolicy: "no-referrer", onLoad: onReady, onError: () => setFailed(true) }),
    React.createElement("figcaption", null,
        React.createElement(Inline, { text: block.caption }),
        React.createElement(Source, { source: block.source })),
    React.createElement("button", { className: "text-button", "data-action": "enlarge", "data-block": block.id }, "Open figure")); }
export function ContentUnits({ page, view, resolveAsset, onReady, print = false }) {
    const nodes = [];
    let serial = 0;
    function unit(b, kind, content, index = 0, offset = 0) { const key = b.id + '.' + index; nodes.push(React.createElement("div", { key: key, className: 'content-unit unit-' + kind, "data-block-id": b.id, "data-unit": key, "data-offset": offset, "data-kind": kind, "data-keep-next": b.layout?.keepWithNext || undefined, "data-break-before": b.layout?.pageBreakBefore || undefined }, content)); }
    function walk(blocks, depth = 0) {
        for (const b of blocks) {
            switch (b.type) {
                case 'section': {
                    const collapsed = !print && (view.collapsed[b.id] ?? b.collapsed ?? false), Tag = depth === 0 ? 'h2' : 'h3';
                    unit(b, 'heading', React.createElement(Tag, null,
                        React.createElement("button", { className: "section-toggle", "data-action": "section", "data-block": b.id, "aria-expanded": !collapsed },
                            React.createElement(Icon, { name: collapsed ? 'chevron' : 'down', size: 16 }),
                            React.createElement("span", null, b.title))));
                    if (!collapsed)
                        walk(b.children, depth + 1);
                    break;
                }
                case 'markdown': {
                    let offset = 0;
                    parseMarkdown(b.text).forEach((p, i) => { let content; if (p.kind === 'paragraph')
                        content = React.createElement("p", null,
                            React.createElement(Inline, { text: p.text }));
                    else if (p.kind === 'heading') {
                        const Tag = p.level <= 2 ? 'h3' : 'h4';
                        content = React.createElement(Tag, null,
                            React.createElement(Inline, { text: p.text }));
                    }
                    else if (p.kind === 'code')
                        content = React.createElement(Code, { code: p.text, language: p.language, id: b.id });
                    else if (p.kind === 'table')
                        content = React.createElement(Table, { columns: p.columns, rows: p.rows });
                    else
                        content = React.createElement(List, { items: p.items, ordered: p.ordered }); unit(b, p.kind, content, i, offset); offset += (p.text?.length ?? p.items?.length ?? p.rows?.length ?? 0) + 1; });
                    break;
                }
                case 'callout':
                    unit(b, 'callout', React.createElement("aside", { className: 'callout ' + (b.tone ?? 'info') },
                        React.createElement("strong", null, b.title),
                        React.createElement("p", null,
                            React.createElement(Inline, { text: b.text }))));
                    break;
                case 'list':
                    unit(b, 'list', React.createElement(List, { items: b.items, ordered: b.ordered }));
                    break;
                case 'table':
                    unit(b, 'table', React.createElement(Table, { columns: b.columns, rows: b.rows }));
                    break;
                case 'code':
                    unit(b, 'code', React.createElement(Code, { code: b.code, language: b.language, title: b.title, id: b.id }));
                    if (b.explanation)
                        unit(b, 'paragraph', React.createElement("p", { className: "code-explanation" },
                            React.createElement(Inline, { text: b.explanation })), 1);
                    if (b.output)
                        unit(b, 'code', React.createElement(Code, { code: b.output, title: "Expected output - not executed", language: "text", id: b.id }), 2);
                    break;
                case 'bilingual':
                    unit(b, 'bilingual', React.createElement("div", { className: 'bilingual ' + (!view.english ? 'no-english' : '') },
                        React.createElement("div", { className: "language-cell", lang: "nb" },
                            React.createElement("span", { className: "language-label" }, "NO"),
                            React.createElement("p", null,
                                React.createElement(Inline, { text: b.no }))),
                        view.english && React.createElement("div", { className: "language-cell english", lang: "en" },
                            React.createElement("span", { className: "language-label" }, "EN"),
                            React.createElement("p", null,
                                React.createElement(Inline, { text: b.en }))),
                        b.hint && React.createElement("small", { className: "language-hint" }, b.hint)));
                    break;
                case 'question': {
                    const visible = !!view.revealed[b.id];
                    unit(b, 'question', React.createElement("div", { className: "question" },
                        React.createElement("div", { className: "eyebrow" }, "REFLECT"),
                        React.createElement("strong", null,
                            React.createElement(Inline, { text: b.question })),
                        !print && React.createElement("button", { className: "text-button", "data-action": "answer", "data-block": b.id, "aria-expanded": visible }, visible ? 'Hide answer' : 'Reveal answer'),
                        visible && React.createElement("div", { className: "answer" },
                            React.createElement(Inline, { text: b.answer }),
                            b.followUp && React.createElement("p", null,
                                React.createElement("strong", null, "Follow-up:"),
                                " ",
                                b.followUp))));
                    break;
                }
                case 'image':
                    unit(b, 'figure', React.createElement(ImageFigure, { block: b, url: resolveAsset(b.src, page), onReady: onReady }));
                    break;
                case 'diagram':
                    unit(b, 'figure', b.format === 'mermaid' && b.code ? React.createElement("figure", null,
                        React.createElement(Mermaid, { code: b.code, onReady: onReady }),
                        React.createElement("figcaption", null,
                            React.createElement(Inline, { text: b.caption }),
                            React.createElement(Source, { source: b.source })),
                        React.createElement("button", { className: "text-button", "data-action": "enlarge", "data-block": b.id }, "Open figure")) : React.createElement(ImageFigure, { block: { ...b, src: b.src, alt: b.caption }, url: b.src ? resolveAsset(b.src, page) : undefined, onReady: onReady }));
                    break;
                case 'link':
                    unit(b, 'link', React.createElement("a", { className: "linked-card", href: '#/page/' + encodeURIComponent(b.pageId), "data-page": b.pageId },
                        React.createElement(Icon, { name: "link" }),
                        React.createElement("span", null,
                            React.createElement("strong", null, b.label ?? b.pageId),
                            b.description && React.createElement("small", null, b.description)),
                        React.createElement(Icon, { name: "right", size: 15 })));
                    break;
                case 'separator':
                    unit(b, 'separator', React.createElement("hr", null));
                    break;
                case 'page_break':
                    unit(b, 'page_break', React.createElement("div", { className: "page-break-label" }, "Page break"));
                    break;
                default: unit(b, 'paragraph', React.createElement("p", { className: "render-error" }, "Unsupported block retained. Export the source to recover it."));
            }
            serial++;
        }
    }
    walk(page.blocks);
    return React.createElement(React.Fragment, null, nodes);
}
