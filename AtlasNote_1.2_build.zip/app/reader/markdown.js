import React from '../vendor/react.mjs';
import { safeUrl } from '../core/validation.mjs';
/** Safe supported Markdown subset. Raw HTML is always literal React text. */
export function Inline({ text }) { const rx = /(`[^`\n]+`|\[\[[A-Za-z0-9][A-Za-z0-9._-]*(?:#[A-Za-z0-9._-]+)?(?:\|[^\]\n]+)?\]\]|\[[^\]\n]+\]\([^\s)]+\)|\*\*[^*]+\*\*|\*[^*\n]+\*)/g; const out = []; let pos = 0; for (const m of String(text ?? '').matchAll(rx)) {
    out.push(text.slice(pos, m.index));
    const s = m[0], key = m.index;
    if (s.startsWith('`'))
        out.push(React.createElement("code", { key: key }, s.slice(1, -1)));
    else if (s.startsWith('[[')) {
        const [ref, label] = s.slice(2, -2).split('|'), [id, block] = ref.split('#');
        out.push(React.createElement("a", { key: key, href: '#/page/' + encodeURIComponent(id) + (block ? '?block=' + encodeURIComponent(block) : ''), "data-page": id, "data-anchor": block }, label ?? id));
    }
    else if (s.startsWith('[')) {
        const x = s.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
        out.push(safeUrl(x[2]) ? React.createElement("a", { key: key, href: x[2], target: "_blank", rel: "noopener noreferrer" }, x[1]) : React.createElement("span", { key: key },
            x[1],
            " (unsafe link omitted)"));
    }
    else if (s.startsWith('**'))
        out.push(React.createElement("strong", { key: key }, s.slice(2, -2)));
    else
        out.push(React.createElement("em", { key: key }, s.slice(1, -1)));
    pos = (m.index ?? 0) + s.length;
} out.push(text.slice(pos)); return React.createElement(React.Fragment, null, out); }
export function parseMarkdown(input) {
    const lines = input.replaceAll('\r\n', '\n').split('\n'), out = [];
    let i = 0;
    while (i < lines.length) {
        if (!lines[i].trim()) {
            i++;
            continue;
        }
        const fence = lines[i].match(/^\s*```([\w+-]*)/);
        if (fence) {
            const rows = [];
            i++;
            while (i < lines.length && !/^\s*```\s*$/.test(lines[i]))
                rows.push(lines[i++]);
            i++;
            out.push({ kind: 'code', text: rows.join('\n'), language: fence[1] || 'text' });
            continue;
        }
        const heading = lines[i].match(/^(#{1,6})\s+(.+)$/);
        if (heading) {
            out.push({ kind: 'heading', text: heading[2], level: heading[1].length });
            i++;
            continue;
        }
        if (lines[i].includes('|') && i + 1 < lines.length && /^\s*\|?\s*:?-{3,}/.test(lines[i + 1])) {
            const cells = (s) => s.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim());
            const columns = cells(lines[i]);
            i += 2;
            const rows = [];
            while (i < lines.length && lines[i].includes('|') && lines[i].trim())
                rows.push(cells(lines[i++]));
            out.push({ kind: 'table', columns, rows });
            continue;
        }
        const list = lines[i].match(/^\s*(?:([-*+])|(\d+)\.)\s+(.+)/);
        if (list) {
            const items = [];
            const ordered = !!list[2];
            while (i < lines.length) {
                const l = lines[i].match(/^\s*(?:([-*+])|(\d+)\.)\s+(.+)/);
                if (!l)
                    break;
                items.push(l[3]);
                i++;
            }
            out.push({ kind: 'list', items, ordered });
            continue;
        }
        const p = [];
        while (i < lines.length && lines[i].trim() && !/^\s*```|^#{1,6}\s|^\s*[-*+]\s/.test(lines[i]))
            p.push(lines[i++]);
        if (!p.length)
            p.push(lines[i++]);
        out.push({ kind: 'paragraph', text: p.join('\n') });
    }
    return out;
}
