import { store } from '../storage/database.js';
import { sha256, safeUrl } from '../core/validation.mjs';
export function assetResolver(built, getCatalogue) {
    const urls = new Map(), cache = new Map();
    function url(key) { const local = store.state.assets.find(a => a.key === key); if (local) {
        if (!urls.has(key))
            urls.set(key, URL.createObjectURL(new Blob([local.bytes], { type: local.mediaType })));
        return urls.get(key);
    } const a = built.assets.find((a) => a.key === key); return a ? new URL(a.path, document.baseURI).href : undefined; }
    async function asset(key) { const local = store.state.assets.find(a => a.key === key); if (local)
        return local; if (cache.has(key))
        return cache.get(key); const meta = built.assets.find((a) => a.key === key); if (!meta)
        return undefined; const response = await fetch(new URL(meta.path, document.baseURI)); if (!response.ok)
        throw Error('Unable to read attachment ' + key); const bytes = new Uint8Array(await response.arrayBuffer()); if (await sha256(bytes) !== meta.sha256)
        throw Error('Attachment hash mismatch: ' + key); const a = { key, bytes, mediaType: meta.mediaType, sha256: meta.sha256 }; cache.set(key, a); return a; }
    function inPage(path, page) { if (safeUrl(path))
        return path; const c = getCatalogue(), pack = c.packs.find(p => p.manifest.id === c.owners[page.id]); if (!pack)
        return undefined; const key = pack.manifest.id + '@' + pack.manifest.version + '/' + path; return url(key); }
    return { url, asset, inPage, async bytes(key) { const a = await asset(key); if (!a)
            throw Error('Attachment missing'); return a.bytes; } };
}
