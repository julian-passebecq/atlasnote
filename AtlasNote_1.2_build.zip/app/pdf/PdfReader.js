import React, { useEffect, useState } from '../vendor/react.mjs';
import { isTrustedPdfatlasDocument, fetchTrustedPdf } from './external-policy.js';
import { Icon } from '../components/Icon.js';
/** The offline build never mislabels an iframe as an integrated PDF engine.
 * The optional separately installed engine is injected by the Vite online entry. */
export function PdfReader({ document: doc, location, onLocation, resolve, fetchBytes }) {
    const [adapter, setAdapter] = useState(null), [error, setError] = useState(''), [consent, setConsent] = useState(false), [show, setShow] = useState(false), [url, setUrl] = useState(undefined), [externalError, setExternalError] = useState(''), [retry, setRetry] = useState(0);
    const trusted = isTrustedPdfatlasDocument(doc);
    useEffect(() => { let active = true; if (window.atlasPdfLoader)
        window.atlasPdfLoader().then(m => { if (active)
            setAdapter(() => m.PdfEngine); }).catch(e => setError('Optional PDF engine failed to load: ' + e.message)); return () => { active = false; }; }, []);
    useEffect(() => {
        const controller = new AbortController();
        let objectUrl;
        let active = true;
        setUrl(doc.assetKey ? resolve(doc.assetKey) : undefined);
        setShow(false);
        setConsent(false);
        setExternalError('');
        if (trusted)
            fetchTrustedPdf(doc, controller.signal).then(bytes => { if (!active)
                return; objectUrl = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' })); setUrl(objectUrl); setConsent(true); setShow(true); }).catch(e => { if (active && e.name !== 'AbortError')
                setExternalError(e.message || 'The public PDF host is unavailable.'); });
        return () => { active = false; controller.abort(); if (objectUrl)
            URL.revokeObjectURL(objectUrl); };
    }, [doc.id, doc.sha256, doc.source.url, doc.assetKey, retry]);
    const external = doc.source.kind === 'https' || doc.source.kind === 'external-link';
    if (trusted && !url)
        return React.createElement("div", { className: "pdf-reader" },
            React.createElement("div", { className: "pdf-intro" },
                React.createElement("div", { className: "eyebrow" }, "PUBLIC PDF LIBRARY"),
                React.createElement("h1", null, doc.title),
                React.createElement("p", null,
                    doc.pageCount,
                    " pages / ",
                    doc.language?.toUpperCase(),
                    " / ",
                    doc.rights.attribution),
                React.createElement("div", { className: "pdf-external-status", role: externalError ? 'alert' : 'status' },
                    React.createElement("strong", null, externalError ? 'Public PDF could not be opened' : 'Opening the verified public reference...'),
                    React.createElement("p", null, externalError || 'Downloading from the configured public library and checking its original SHA-256. No private workspace data is sent.'),
                    React.createElement("code", null, doc.source.url),
                    externalError && React.createElement("button", { onClick: () => setRetry(n => n + 1) }, "Retry public PDF"),
                    React.createElement("p", null, "This is an external reference. Its bytes are not in your workspace backup unless you import the PDF locally."))));
    if (adapter) {
        const Component = adapter;
        return React.createElement(Component, { document: doc, location: location, onLocation: onLocation, url: trusted ? url : external ? (consent ? doc.source.url : undefined) : url, requestExternal: () => setConsent(true) });
    }
    return React.createElement("div", { className: 'pdf-reader' + (show ? ' has-preview' : '') },
        React.createElement("div", { className: "pdf-intro" },
            React.createElement("div", { className: "eyebrow" }, "PDF DOCUMENT"),
            React.createElement("h1", null, doc.title),
            React.createElement("p", null, doc.rights.attribution),
            trusted && React.createElement("p", { className: "secondary" }, "Verified public reference / SHA-256 checked / not stored offline"),
            React.createElement("div", { className: "pdf-engine-notice", role: "status" },
                React.createElement(Icon, { name: "help" }),
                React.createElement("div", null,
                    React.createElement("strong", null, "Browser preview only in this offline build"),
                    React.createElement("p", null, "The integrated PDF engine is not bundled. Atlas page navigation, selectable-text search, rotation and physical-page spreads are unavailable here. Local PDF bytes are preserved in imports and backups. External references are backed up as metadata only."))),
            error && React.createElement("p", { role: "alert" }, error),
            external && !trusted && !consent ? React.createElement("div", { className: "callout" },
                React.createElement("p", null, "Opening this PDF contacts its external host. The full URL is shown before any request."),
                React.createElement("code", null, doc.source.url),
                React.createElement("button", { onClick: () => { setConsent(true); setUrl(doc.source.url); } }, "Allow external PDF reference")) : url ? React.createElement("div", { className: "button-row" },
                React.createElement("button", { className: "primary", onClick: () => setShow(v => !v) }, show ? 'Hide browser preview' : 'Show browser PDF preview'),
                React.createElement("a", { className: "button", href: url, target: "_blank", rel: "noopener noreferrer" }, "Open original PDF"),
                React.createElement("a", { className: "button", href: url, download: doc.title + '.pdf' }, "Download original")) : React.createElement("div", { className: "callout warning" },
                React.createElement("strong", null, "PDF bytes are unavailable"),
                React.createElement("p", null, "This document is a reference to a local library file that has not been imported. Import the original PDF through Settings. Atlas does not invent its pages.")),
            React.createElement("details", { className: "pdf-metadata" },
                React.createElement("summary", null, "Document identity & provenance"),
                React.createElement("dl", null,
                    React.createElement("dt", null, "Visibility"),
                    React.createElement("dd", null, doc.visibility),
                    React.createElement("dt", null, "Document ID"),
                    React.createElement("dd", null, doc.id),
                    React.createElement("dt", null, "SHA-256 revision"),
                    React.createElement("dd", null,
                        React.createElement("code", null, doc.sha256 ?? 'External reference - no verified local bytes')),
                    React.createElement("dt", null, "Rights"),
                    React.createElement("dd", null, doc.rights.status),
                    React.createElement("dt", null, "Bytes"),
                    React.createElement("dd", null, doc.bytes ?? 'Not imported')))),
        show && url && React.createElement("iframe", { className: "pdf-fallback", src: url, title: 'Browser PDF preview: ' + doc.title, referrerPolicy: "no-referrer" }));
}
