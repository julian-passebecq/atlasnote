import React, { useState, useEffect, useLayoutEffect, useRef } from '../vendor/react.mjs';
import { Icon, IconButton } from './Icon.js';
import { visibleLibraryNode } from '../core/library-projection.js';
import { normalize } from '../core/workspace.js';
/** All tree actions also have an ordinary, keyboard-focusable Actions button. */
export function ProjectTree({ catalogue: c, workspace: ws, activePage, panePages = [], activePaneIndex = 0, onCollection, onOpen, onOther, onBookmark, onToggle, onItem, onCreate }) {
    const [filter, setFilter] = useState(''), [menu, setMenu] = useState(null);
    const menuRef = useRef(null);
    const expanded = new Set(ws.personal.session.expanded), archived = new Set(ws.overlays.archived), query = normalize(filter);
    const mode = ws.personal.session.libraryMode ?? 'notes', pdfPages = new Set(c.documents.map((d) => d.pageId));
    const visible = (n) => visibleLibraryNode(n, pdfPages, archived, mode);
    const matches = (n) => !query || normalize(n.title).includes(query) || !!n.children?.some(matches);
    const hidden = (p) => ws.overlays.projectPrefs[p.id]?.hidden || archived.has(p.id);
    function dismiss(restoreFocus = true) { const target = menu?.returnFocus; setMenu(null); if (restoreFocus && target?.isConnected)
        target.focus(); }
    function showMenu(e, project, node) {
        e.preventDefault();
        e.stopPropagation();
        const el = e.currentTarget, r = el.getBoundingClientRect();
        setMenu({ project, node, x: e.clientX || r.left, y: e.clientY || r.bottom, returnFocus: el.matches('button') ? el : el.querySelector('button') ?? el });
    }
    function keyboardMenu(e, p, n) { if (e.key === 'ContextMenu' || e.shiftKey && e.key === 'F10')
        showMenu(e, p, n); }
    useLayoutEffect(() => {
        const el = menuRef.current;
        if (!menu || !el)
            return;
        const r = el.getBoundingClientRect();
        el.style.left = Math.max(8, Math.min(menu.x, window.innerWidth - r.width - 8)) + 'px';
        el.style.top = Math.max(8, Math.min(menu.y, window.innerHeight - r.height - 8)) + 'px';
        el.querySelector('[role="menuitem"]')?.focus();
    }, [menu]);
    useEffect(() => {
        if (!menu)
            return;
        const outside = (e) => { if (!menuRef.current?.contains(e.target))
            dismiss(false); };
        const resize = () => dismiss(false);
        document.addEventListener('pointerdown', outside);
        window.addEventListener('resize', resize);
        return () => { document.removeEventListener('pointerdown', outside); window.removeEventListener('resize', resize); };
    }, [menu]);
    function action(fn) { dismiss(false); fn(); }
    function menuKey(e) {
        const buttons = [...(menuRef.current?.querySelectorAll('[role="menuitem"]') ?? [])];
        const i = buttons.indexOf(document.activeElement);
        if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            dismiss();
        }
        else if (e.key === 'Tab') {
            dismiss();
        }
        else if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) {
            e.preventDefault();
            const next = e.key === 'Home' ? 0 : e.key === 'End' ? buttons.length - 1 : (i + (e.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length;
            buttons[next]?.focus();
        }
    }
    function nodes(ns, p, depth) {
        return ns.filter(n => visible(n) && matches(n)).map(n => {
            const owners = [0, 1].filter(i => n.pageId && panePages[i] === n.pageId);
            const open = expanded.has(n.id) || !!query, page = c.pages.find((p) => p.id === n.pageId);
            return React.createElement("div", { className: "tree-node", key: n.id },
                React.createElement("div", { className: 'tree-row ' + (n.pageId === activePage ? 'active ' : '') + owners.map(i => 'pane-owner-' + (i === 0 ? 'a' : 'b')).join(' '), "data-node-id": n.id, "data-pane-owners": owners.map(i => i === 0 ? 'a' : 'b').join(' '), style: { paddingLeft: (10 + depth * 14) + 'px' }, onContextMenu: e => showMenu(e, p, n), onKeyDown: e => keyboardMenu(e, p, n) },
                    React.createElement(React.Fragment, null,
                        n.children && React.createElement("button", { className: "tree-expander", "aria-label": (open ? 'Collapse ' : 'Expand ') + n.title, "aria-expanded": open, onClick: () => onToggle(n.id) },
                            React.createElement(Icon, { name: open ? 'down' : 'chevron', size: 12 })),
                        React.createElement("button", { className: "tree-target", title: n.title, "aria-expanded": n.children ? open : undefined, "aria-current": n.pageId === activePage ? 'page' : undefined, onClick: e => n.pageId ? onOpen(n.pageId, undefined, e.ctrlKey || e.metaKey) : (onCollection(n.id, undefined, e.ctrlKey || e.metaKey), !open && onToggle(n.id)), onAuxClick: e => { if (e.button === 1) {
                                e.preventDefault();
                                onOpen(n.pageId ?? n.id, undefined, true);
                            } } },
                            !n.children && React.createElement("span", { className: "tree-indent" }),
                            React.createElement(Icon, { name: n.children ? 'folder' : c.documents.some((d) => d.pageId === n.pageId) ? 'pdf' : 'page', size: 15 }),
                            React.createElement("span", null, page?.title ?? n.title))),
                    owners.length > 0 && React.createElement("span", { className: "tree-pane-markers", "aria-label": owners.length === 2 ? 'Open in panes A and B' : 'Open in pane ' + (owners[0] === 0 ? 'A' : 'B') }, owners.map(i => React.createElement("span", { key: i, className: 'tree-pane-marker marker-' + (i === 0 ? 'a' : 'b') + (i === activePaneIndex ? ' is-active' : '') }, i === 0 ? 'A' : 'B'))),
                    n.pageId && ws.personal.session.showFlags && ws.personal.ratings[n.pageId] && React.createElement("span", { className: 'flag-dot ' + ws.personal.ratings[n.pageId], title: ws.personal.ratings[n.pageId] }),
                    React.createElement(IconButton, { name: "more", label: 'Actions for ' + n.title, className: "tree-more", "aria-haspopup": "menu", onClick: e => showMenu(e, p, n) })),
                n.children && open && React.createElement("div", { className: "tree-children" }, n.children.length ? nodes(n.children, p, depth + 1) : React.createElement("button", { className: "empty-folder", style: { marginLeft: (30 + depth * 14) + 'px' }, onClick: () => onCreate('page', p, n) }, "Add a page")));
        });
    }
    function project(p) {
        if (hidden(p) || mode === 'pdfs' && !p.nodes.some(visible))
            return null;
        const open = expanded.has(p.id) || !!query;
        if (query && !normalize(p.title).includes(query) && !p.nodes.some(matches))
            return null;
        return React.createElement("div", { className: "tree-project", key: p.id },
            React.createElement("div", { className: "tree-row project-row", onContextMenu: e => showMenu(e, p), onKeyDown: e => keyboardMenu(e, p) },
                React.createElement("button", { className: "tree-expander", "aria-label": (open ? 'Collapse ' : 'Expand ') + p.title, "aria-expanded": open, onClick: () => onToggle(p.id) },
                    React.createElement(Icon, { name: open ? 'down' : 'chevron', size: 12 })),
                React.createElement("button", { className: "tree-target", onClick: e => { onCollection(p.id, undefined, e.ctrlKey || e.metaKey); if (!open)
                        onToggle(p.id); }, title: p.title },
                    React.createElement("span", { className: "project-icon" },
                        React.createElement(Icon, { name: p.icon, size: 17 })),
                    React.createElement("strong", null, p.title)),
                React.createElement(IconButton, { name: "more", label: 'Actions for notebook ' + p.title, className: "tree-more", "aria-haspopup": "menu", onClick: e => showMenu(e, p) }),
                React.createElement(IconButton, { name: "plus", label: 'Add to ' + p.title, className: "tree-more", onClick: () => onCreate('page', p) })),
            open && nodes(p.nodes, p, 0));
    }
    const grouped = new Set(c.groups.flatMap((g) => g.projectIds));
    const menuPage = menu?.node?.pageId;
    const firstPage = (ns) => { for (const n of ns) {
        if (!visible(n))
            continue;
        if (n.pageId && !archived.has(n.pageId))
            return n.pageId;
        const id = n.children && firstPage(n.children);
        if (id)
            return id;
    } };
    const overview = menu && !menuPage ? firstPage(menu.node?.children ?? menu.project.nodes) : undefined;
    const manage = (intent) => { if (menu)
        action(() => onItem({ project: menu.project, node: menu.node, intent })); };
    return React.createElement("aside", { className: "library-sidebar", "aria-label": "Notebook library" },
        React.createElement("div", { className: "sidebar-heading" },
            React.createElement("strong", null, mode === 'pdfs' ? 'PDF Library' : 'My notebooks'),
            React.createElement("span", { className: "secondary" }, c.projects.filter((p) => !hidden(p) && (mode !== 'pdfs' || p.nodes.some(visible))).length)),
        React.createElement("div", { className: "tree-filter" },
            React.createElement(Icon, { name: "search", size: 15 }),
            React.createElement("input", { "aria-label": "Filter notebook tree", placeholder: "Filter notebooks", value: filter, onChange: e => setFilter(e.target.value) }),
            filter && React.createElement(IconButton, { name: "close", label: "Clear tree filter", onClick: () => setFilter('') })),
        React.createElement("nav", { className: "tree-scroll", "aria-label": "Projects and pages" },
            c.groups.filter((g) => g.projectIds.some((id) => c.projects.some((p) => p.id === id && !hidden(p) && (mode !== 'pdfs' || p.nodes.some(visible))))).map((g) => React.createElement("section", { className: "tree-group", key: g.id },
                React.createElement("h3", null, g.title),
                g.projectIds.map((id) => c.projects.find((p) => p.id === id)).filter(Boolean).map(project))),
            c.projects.filter((p) => !grouped.has(p.id)).length > 0 && React.createElement("section", { className: "tree-group" },
                React.createElement("h3", null, "NOTEBOOKS"),
                c.projects.filter((p) => !grouped.has(p.id)).map(project))),
        React.createElement("button", { className: "sidebar-add", onClick: () => onCreate('project') },
            React.createElement(Icon, { name: "plus", size: 16 }),
            " New notebook"),
        React.createElement("div", { className: "local-status" },
            React.createElement("span", { className: "status-dot" }),
            " Stored on this device"),
        menu && React.createElement("div", { ref: menuRef, className: "tree-context-menu", role: "menu", "aria-label": 'Actions for ' + (menu.node?.title ?? menu.project.title), style: { left: menu.x, top: menu.y }, onKeyDown: menuKey },
            React.createElement("div", { className: "tree-menu-title" }, menu.node?.title ?? menu.project.title),
            menuPage ? React.createElement(React.Fragment, null,
                React.createElement("button", { role: "menuitem", onClick: () => action(() => onOpen(menuPage)) },
                    React.createElement(Icon, { name: "page" }),
                    "Open"),
                React.createElement("button", { role: "menuitem", onClick: () => action(() => onOpen(menuPage, undefined, true)) },
                    React.createElement(Icon, { name: "plus" }),
                    "Open in new tab"),
                onOther && React.createElement("button", { role: "menuitem", onClick: () => action(() => onOther(menuPage)) },
                    React.createElement(Icon, { name: "split" }),
                    "Open in other pane"),
                React.createElement("button", { role: "menuitem", onClick: () => action(() => onBookmark(menuPage)) },
                    React.createElement(Icon, { name: "bookmark" }),
                    "Bookmark")) : React.createElement(React.Fragment, null,
                React.createElement("button", { role: "menuitem", onClick: () => action(() => onCollection(menu.node?.id ?? menu.project.id)) },
                    React.createElement(Icon, { name: "folder" }),
                    "Open collection"),
                overview && React.createElement("button", { role: "menuitem", onClick: () => action(() => onOpen(overview)) },
                    React.createElement(Icon, { name: "book" }),
                    "Open overview"),
                React.createElement("button", { role: "menuitem", onClick: () => action(() => onCreate('page', menu.project, menu.node)) },
                    React.createElement(Icon, { name: "plus" }),
                    "Add page"),
                React.createElement("button", { role: "menuitem", onClick: () => action(() => onCreate('folder', menu.project, menu.node)) },
                    React.createElement(Icon, { name: "folder" }),
                    "Add folder")),
            React.createElement("div", { role: "separator" }),
            React.createElement("button", { role: "menuitem", onClick: () => manage('rename') },
                React.createElement(Icon, { name: "edit" }),
                "Rename"),
            React.createElement("button", { role: "menuitem", onClick: () => manage('move') },
                React.createElement(Icon, { name: "folder" }),
                menu.node ? 'Move' : 'Move / group notebook'),
            React.createElement("button", { role: "menuitem", onClick: () => manage('archive') },
                React.createElement(Icon, { name: "archive" }),
                "Archive")));
}
