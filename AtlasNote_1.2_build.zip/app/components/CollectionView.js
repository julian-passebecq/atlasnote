import React, { ReactDOM, useEffect, useLayoutEffect, useMemo, useRef, useState } from '../vendor/react.mjs';
import { visibleLibraryNode } from '../core/library-projection.js';
import { FLAG_LABELS } from '../core/model.js';
import { collectionItems, collectionTarget, filterCollection } from '../core/collections.js';
import { Icon, IconButton } from './Icon.js';
const initial = { type: 'all', language: '', domain: '', technology: '', text: '', sort: 'tree' };
export function CollectionView({ id, catalogue, workspace, onOpen, onOther, onManage, onBookmark, onCreate, onImport }) {
    const target = collectionTarget(catalogue, id);
    const [filter, setFilter] = useState(initial), [menu, setMenu] = useState(null);
    const menuRef = useRef(null);
    const pdfMode = workspace.personal.session.libraryMode === 'pdfs';
    const items = useMemo(() => { const all = collectionItems(catalogue, workspace.overlays, id), pdfs = new Set(catalogue.documents.map(d => d.pageId)), archived = new Set(workspace.overlays.archived); return pdfMode ? all.filter(i => visibleLibraryNode(i.node, pdfs, archived, 'pdfs')) : all; }, [catalogue, workspace.overlays, id, pdfMode]);
    const shown = filterCollection(items, pdfMode ? { ...filter, type: 'all' } : filter);
    const options = (key) => [...new Set(items.flatMap(i => key === 'language' ? [i.language] : i[key]))].sort();
    const change = (key, value) => setFilter(f => ({ ...f, [key]: value }));
    function dismiss(restore = false) { const origin = menu?.returnFocus; setMenu(null); if (restore)
        origin?.focus(); }
    function show(e, item) { e.preventDefault(); e.stopPropagation(); const el = e.currentTarget, r = el.getBoundingClientRect(); setMenu({ item, x: e.clientX || r.left, y: e.clientY || r.bottom, returnFocus: (e.target instanceof Element ? e.target.closest('button') : null) ?? (el.matches('button') ? el : el.querySelector('.collection-open')) ?? el }); }
    function choose(fn) { dismiss(); fn(); }
    function open(item, newTab = false) { onOpen(item.page?.id ?? item.node.id, undefined, newTab); }
    useLayoutEffect(() => { if (!menu || !menuRef.current)
        return; const r = menuRef.current.getBoundingClientRect(); menuRef.current.style.left = Math.max(8, Math.min(menu.x, innerWidth - r.width - 8)) + 'px'; menuRef.current.style.top = Math.max(8, Math.min(menu.y, innerHeight - r.height - 8)) + 'px'; menuRef.current.querySelector('[role="menuitem"]')?.focus(); }, [menu]);
    useEffect(() => { if (!menu)
        return; const outside = (e) => { if (!menuRef.current?.contains(e.target))
        dismiss(); }; document.addEventListener('pointerdown', outside); return () => document.removeEventListener('pointerdown', outside); }, [menu]);
    function menuKey(e) { const buttons = [...(menuRef.current?.querySelectorAll('[role="menuitem"]') ?? [])], at = buttons.indexOf(document.activeElement); if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        dismiss(true);
    }
    else if (e.key === 'Tab')
        dismiss();
    else if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) {
        e.preventDefault();
        buttons[e.key === 'Home' ? 0 : e.key === 'End' ? buttons.length - 1 : (at + (e.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length]?.focus();
    } }
    if (!target)
        return React.createElement("div", { className: "empty-pane" },
            React.createElement("h2", null, "Folder unavailable"),
            React.createElement("p", null, "This reading thread is retained. Restore its library or use Back."));
    return React.createElement("main", { className: "collection-view", "aria-label": 'Collection: ' + target.title },
        React.createElement("header", { className: "collection-heading" },
            React.createElement("div", null,
                React.createElement("div", { className: "eyebrow" }, "FOLDER COLLECTION"),
                React.createElement("h1", null, target.title),
                React.createElement("p", null,
                    target.path.join(' / '),
                    " ",
                    React.createElement("span", { "aria-hidden": "true" }, " / "),
                    " ",
                    items.length,
                    " direct items")),
            React.createElement("span", { className: "project-icon large" },
                React.createElement(Icon, { name: target.folder ? 'folder' : target.project.icon, size: 25 }))),
        React.createElement("div", { className: "collection-actions" },
            React.createElement("button", { onClick: () => onCreate('page', target.project, target.folder) },
                React.createElement(Icon, { name: "plus" }),
                "New note"),
            React.createElement("button", { onClick: () => onCreate('folder', target.project, target.folder) },
                React.createElement(Icon, { name: "folder" }),
                "New folder"),
            React.createElement("button", { onClick: () => onImport(target.project.id, target.folder?.id) },
                React.createElement(Icon, { name: "pdf" }),
                "Import PDF privately")),
        React.createElement("section", { className: "collection-filters", "aria-label": "Filter collection" },
            React.createElement("div", { className: "collection-type-filter", "aria-label": "Document type" }, (pdfMode ? [['all', 'PDF Library']] : [['all', 'All'], ['note', 'Notes'], ['pdf', 'PDFs']]).map(([value, label]) => React.createElement("button", { key: value, "aria-pressed": filter.type === value, className: filter.type === value ? 'selected' : '', onClick: () => change('type', value) }, label))),
            React.createElement("label", { className: "collection-text-filter" },
                React.createElement(Icon, { name: "search", size: 16 }),
                React.createElement("input", { "aria-label": "Search this collection", value: filter.text, placeholder: "Filter title, summary or tags", onChange: e => change('text', e.target.value) })),
            React.createElement("label", null,
                "Language",
                React.createElement("select", { "aria-label": "Collection language", value: filter.language, onChange: e => change('language', e.target.value) },
                    React.createElement("option", { value: "" }, "All languages"),
                    options('language').map(v => React.createElement("option", { key: v, value: v }, v === 'unknown' ? 'Unknown' : v.toUpperCase())))),
            React.createElement("label", null,
                "Domain",
                React.createElement("select", { "aria-label": "Collection domain", value: filter.domain, onChange: e => change('domain', e.target.value) },
                    React.createElement("option", { value: "" }, "All domains"),
                    options('domains').map(v => React.createElement("option", { key: v }, v)))),
            React.createElement("label", null,
                "Technology",
                React.createElement("select", { "aria-label": "Collection technology", value: filter.technology, onChange: e => change('technology', e.target.value) },
                    React.createElement("option", { value: "" }, "All technologies"),
                    options('technologies').map(v => React.createElement("option", { key: v }, v)))),
            React.createElement("label", null,
                "Sort",
                React.createElement("select", { "aria-label": "Collection sort", value: filter.sort, onChange: e => change('sort', e.target.value) },
                    React.createElement("option", { value: "tree" }, "Tree order"),
                    React.createElement("option", { value: "title" }, "Title A-Z")))),
        React.createElement("div", { className: "collection-results-label", role: "status" },
            shown.length,
            " of ",
            items.length,
            " items ",
            React.createElement("button", { className: "text-button", onClick: () => setFilter({ ...initial }) }, "Reset filters")),
        React.createElement("div", { className: "collection-grid" }, shown.map(item => {
            const title = item.page?.title ?? item.node.title;
            return React.createElement("article", { className: "collection-card", key: item.node.id, "data-item-type": item.type, "data-node-id": item.node.id, onContextMenu: e => show(e, item), onKeyDown: e => { if (e.key === 'ContextMenu' || e.shiftKey && e.key === 'F10')
                    show(e, item); } },
                React.createElement("div", { className: "collection-card-top" },
                    React.createElement("span", { className: 'collection-type-icon type-' + item.type },
                        React.createElement(Icon, { name: item.type === 'note' ? 'page' : item.type, size: 21 })),
                    React.createElement("span", { className: "badge" }, item.type === 'pdf' ? 'PDF' : item.type === 'note' ? 'Note' : 'Folder'),
                    React.createElement(IconButton, { name: "more", label: 'Collection actions for ' + title, "aria-haspopup": "menu", onClick: e => show(e, item) })),
                React.createElement("button", { className: "collection-open", title: title, onClick: e => open(item, e.ctrlKey || e.metaKey), onAuxClick: e => { if (e.button === 1) {
                        e.preventDefault();
                        open(item, true);
                    } } }, title),
                React.createElement("p", { className: "collection-summary" }, item.summary || 'No summary yet.'),
                React.createElement("div", { className: "collection-facets" }, (item.page?.tags ?? []).filter(t => /^(doctype|domain|tech|level|source):/.test(t)).map(tag => React.createElement("span", { className: "facet-chip", key: tag, title: tag }, tag))),
                React.createElement("footer", { className: "collection-card-meta" },
                    React.createElement("span", null,
                        item.language === 'unknown' ? 'Language unknown' : item.language.toUpperCase(),
                        item.document?.pageCount ? ' / ' + item.document.pageCount + ' pages' : ''),
                    item.page && workspace.personal.session.showFlags && React.createElement("span", { className: "collection-flag" },
                        React.createElement("span", { className: 'flag-dot ' + (workspace.personal.ratings[item.page.id] ?? 'gray') }),
                        FLAG_LABELS[workspace.personal.ratings[item.page.id] ?? 'gray'])));
        })),
        !shown.length && React.createElement("div", { className: "empty-state" },
            React.createElement(Icon, { name: "folder", size: 34 }),
            React.createElement("h2", null, items.length ? 'No matching items' : 'A place for notes and PDFs'),
            React.createElement("p", null, items.length ? 'Change a filter to see more of this folder.' : 'Add a note, create a subfolder or import a private PDF. The tree stays the source of truth.')),
        menu && ReactDOM.createPortal(React.createElement("div", { ref: menuRef, className: "tree-context-menu collection-context-menu", role: "menu", "aria-label": 'Collection actions for ' + (menu.item.page?.title ?? menu.item.node.title), style: { left: menu.x, top: menu.y }, onKeyDown: menuKey },
            React.createElement("div", { className: "tree-menu-title" }, menu.item.page?.title ?? menu.item.node.title),
            React.createElement("button", { role: "menuitem", onClick: () => choose(() => open(menu.item)) },
                React.createElement(Icon, { name: "page" }),
                "Open"),
            React.createElement("button", { role: "menuitem", onClick: () => choose(() => open(menu.item, true)) },
                React.createElement(Icon, { name: "plus" }),
                "Open in new tab"),
            onOther && React.createElement("button", { role: "menuitem", onClick: () => choose(() => onOther(menu.item.page?.id ?? menu.item.node.id)) },
                React.createElement(Icon, { name: "split" }),
                "Open in other pane"),
            menu.item.page && React.createElement("button", { role: "menuitem", onClick: () => choose(() => onBookmark(menu.item.page.id)) },
                React.createElement(Icon, { name: "bookmark" }),
                "Bookmark"),
            React.createElement("div", { role: "separator" }),
            ['rename', 'move', 'archive'].map(intent => React.createElement("button", { key: intent, role: "menuitem", onClick: () => choose(() => onManage({ project: menu.item.project, node: menu.item.node, intent })) },
                React.createElement(Icon, { name: intent === 'rename' ? 'edit' : intent === 'move' ? 'folder' : 'archive' }),
                intent[0].toUpperCase() + intent.slice(1)))), document.body));
}
