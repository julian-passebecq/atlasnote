import React, { useEffect, useState } from '../vendor/react.mjs';
import { Modal, Field } from './Modal.js';
import { Icon } from './Icon.js';
import { store, rawRecovery } from '../storage/database.js';
import { unzipBounded, makeBackup, readBackup, download } from '../storage/archives.mjs';
import { readWorkspace, planImport } from '../core/packs.mjs';
import { compose } from '../core/workspace.js';
import { schemas } from '../app/load.js';
import { THEME_LABELS } from '../core/model.js';
import { PdfIntake } from './PdfIntake.js';
import { duplicatePdfImports } from '../core/pdf-library.js';
import { exportPrivatePdfLibrary } from '../core/export-pdf-library.mjs';
import { exportRepositoryWorkspace } from '../core/export-pack.mjs';
export function SettingsDialog({ built, catalogue: c, assets, initialProject, initialFolder, onClose, onOpen, notify }) {
    const [busy, setBusy] = useState(''), [error, setError] = useState(''), [preview, setPreview] = useState(null), [restore, setRestore] = useState(null), [confirmRestore, setConfirmRestore] = useState(false), [usage, setUsage] = useState(null), [backupMessage, setBackupMessage] = useState('');
    const [pdfExportId, setPdfExportId] = useState('atlas.private-pdf-library'), [pdfExportVersion, setPdfExportVersion] = useState('1.0.0');
    useEffect(() => { navigator.storage?.estimate?.().then(setUsage).catch(() => { }); }, []);
    async function action(label, fn) {
        setBusy(label);
        setError('');
        try {
            await fn();
        }
        catch (e) {
            setError(e.message);
        }
        finally {
            setBusy('');
        }
    }
    async function importLibrary(file) {
        setPreview(null);
        await action('Validating library...', async () => {
            const result = await unzipBounded(file);
            if (result.transfer?.kind === 'backup')
                throw Error('This is a workspace backup. Use Restore backup below.');
            const input = await readWorkspace(result.files, await schemas(), { allowUnresolved: true });
            const active = compose(built, store.state);
            const plan = planImport(active.packs, input.packs, store.state.overlays);
            plan.conflicts.push(...duplicatePdfImports(active, input.packs));
            setPreview({ ...input, plan, name: file.name, size: result.bytes });
        });
    }
    async function commitLibrary() {
        await action('Importing library...', async () => {
            const current = compose(built, store.state), plan = planImport(current.packs, preview.packs, store.state.overlays);
            plan.conflicts.push(...duplicatePdfImports(current, preview.packs));
            if (plan.conflicts.length) {
                setPreview((p) => ({ ...p, plan }));
                throw Error('The workspace changed or has conflicts. Review the preview; nothing was imported.');
            }
            const changed = preview.packs.filter((p) => !plan.unchanged.includes(p.manifest.id)), overlays = structuredClone(store.state.overlays);
            overlays.groups = structuredClone(overlays.groups ?? built.groups);
            for (const group of preview.workspace.groups) {
                const old = overlays.groups.find(g => g.id === group.id);
                if (old)
                    old.projectIds = [...new Set([...old.projectIds, ...group.projectIds])];
                else
                    overlays.groups.push(group);
            }
            await store.importPacks(changed, preview.assets, overlays);
            setPreview(null);
            notify(changed.length ? 'Library imported. Your additions and personal state were retained.' : 'This library is already imported. No content changes were needed.');
        });
    }
    async function backup() { await action('Preparing verified backup...', async () => { await store.flush(); const result = await makeBackup(store.state, built, assets.asset); download(result.bytes, 'knowledge-atlas-workspace.atlas-backup.zip'); setBackupMessage('Backup downloaded. It contains local content, attachments, remarks, flags, bookmarks and view state.' + (result.external.length ? ' ' + result.external.length + ' external image references remain links; their remote bytes are not included.' : '')); }); }
    async function previewRestore(file) { setRestore(null); setConfirmRestore(false); await action('Validating backup...', async () => { const { files } = await unzipBounded(file); setRestore(await readBackup(files, await schemas())); }); }
    async function commitRestore() {
        await action('Restoring workspace...', async () => {
            if (!confirmRestore)
                throw Error('Confirm replacement before restoring');
            await store.restore(restore.workspace);
            notify('Workspace restored from verified bytes.');
            setRestore(null);
            onClose();
        });
    }
    return React.createElement(Modal, { title: "Workspace settings", onClose: onClose, wide: true },
        React.createElement("div", { className: "settings-layout" },
            React.createElement("section", { className: "settings-section" },
                React.createElement("h3", null,
                    React.createElement(Icon, { name: "upload" }),
                    " Import library"),
                React.createElement("p", null, "Import a canonical Atlas ZIP. You will see its content, visibility, ID conflicts and version changes before committing."),
                React.createElement("label", { className: "file-picker" },
                    "Choose library ZIP",
                    React.createElement("input", { "aria-label": "Import library ZIP", type: "file", accept: ".zip", disabled: !!busy, onChange: e => {
                            const f = e.target.files?.[0];
                            if (f)
                                importLibrary(f);
                            e.target.value = '';
                        } })),
                preview && React.createElement("div", { className: "import-preview" },
                    React.createElement("h4", null,
                        "Review: ",
                        preview.name),
                    React.createElement("div", { className: "preview-stats" },
                        React.createElement("span", null,
                            React.createElement("strong", null, preview.validation.pages),
                            " pages"),
                        React.createElement("span", null,
                            React.createElement("strong", null, preview.validation.terms),
                            " terms"),
                        React.createElement("span", null,
                            React.createElement("strong", null, preview.validation.projects),
                            " projects")),
                    React.createElement("p", null,
                        preview.plan.addedPages.length,
                        " new pages; ",
                        preview.plan.changed.length,
                        " updated packs; ",
                        preview.plan.unchanged.length,
                        " unchanged packs; ",
                        preview.plan.moves.length,
                        " recorded source moves."),
                    React.createElement("ul", null, preview.packs.map((p) => React.createElement("li", { key: p.manifest.id },
                        React.createElement("code", null, p.manifest.id),
                        " ",
                        p.manifest.version,
                        " ",
                        React.createElement("span", { className: "badge" }, p.manifest.visibility)))),
                    React.createElement("p", { className: "privacy-note" }, "This import stays on this device. It does not upload or publish anything. Your existing additions, remarks, ratings, bookmarks and open views are retained."),
                    preview.plan.conflicts.length > 0 ? React.createElement("div", { className: "error-message" },
                        React.createElement("strong", null, "Import blocked. No changes committed."),
                        preview.plan.conflicts.map((s, i) => React.createElement("p", { key: i }, s))) : React.createElement("p", { className: "success-message" }, "Stable IDs, dependencies, relationships and attachment checksums passed validation."),
                    React.createElement("div", { className: "button-row" },
                        React.createElement("button", { onClick: () => setPreview(null), disabled: !!busy }, "Cancel import"),
                        React.createElement("button", { className: "primary", disabled: !!busy || !!preview.plan.conflicts.length, onClick: commitLibrary }, "Confirm library import")))),
            React.createElement(PdfIntake, { built: built, catalogue: c, initialProject: initialProject, initialFolder: initialFolder, onClose: onClose, onOpen: onOpen, notify: notify, disabled: !!busy }),
            React.createElement("section", { className: "settings-section" },
                React.createElement("h3", null,
                    React.createElement(Icon, { name: "download" }),
                    " Backup & recovery"),
                React.createElement("p", null, "A complete workspace backup contains content snapshots, local PDF bytes and your personal state. Keep it private. A content export is not a substitute for this backup."),
                React.createElement("button", { className: "primary", onClick: backup, disabled: !!busy },
                    React.createElement(Icon, { name: "download" }),
                    " Download workspace backup"),
                backupMessage && React.createElement("p", { className: "success-message" }, backupMessage),
                React.createElement("label", { className: "file-picker secondary-picker" },
                    "Choose backup to restore",
                    React.createElement("input", { "aria-label": "Restore workspace backup", type: "file", accept: ".zip", disabled: !!busy, onChange: e => {
                            const f = e.target.files?.[0];
                            if (f)
                                previewRestore(f);
                            e.target.value = '';
                        } })),
                restore && React.createElement("div", { className: "import-preview" },
                    React.createElement("h4", null, "Restore preview"),
                    React.createElement("p", null,
                        restore.workspace.imports.length,
                        " pack snapshots, ",
                        Object.keys(restore.workspace.personal.notes).length,
                        " saved remarks, ",
                        restore.workspace.personal.bookmarks.length,
                        " bookmarks and ",
                        restore.workspace.assets.length,
                        " verified attachments."),
                    React.createElement("p", { className: "warning-text" }, "Restore replaces this browser's saved workspace, including its personal state. Download a backup of this workspace first. Newer built-in source revisions still take precedence over older imported snapshots."),
                    React.createElement("label", { className: "inline-check" },
                        React.createElement("input", { type: "checkbox", checked: confirmRestore, onChange: e => setConfirmRestore(e.target.checked) }),
                        " I understand that this replaces the current local workspace."),
                    React.createElement("div", { className: "button-row" },
                        React.createElement("button", { onClick: () => setRestore(null) }, "Cancel restore"),
                        React.createElement("button", { className: "primary", onClick: commitRestore, disabled: !confirmRestore || !!busy }, "Restore verified backup"))),
                store.error && React.createElement("div", { className: "error-message" },
                    React.createElement("p", null, store.error),
                    React.createElement("button", { onClick: () => action('Retrying save...', () => store.retry()) }, "Retry saving"),
                    React.createElement("button", { onClick: () => action('Preparing raw recovery...', async () => { download(JSON.stringify(await rawRecovery(), (_k, v) => v instanceof Uint8Array ? { type: 'Uint8Array', bytes: [...v] } : v, 2), 'atlas-raw-recovery.json', 'application/json'); }) }, "Download raw recovery JSON"))),
            React.createElement("section", { className: "settings-section" },
                React.createElement("h3", null,
                    React.createElement(Icon, { name: "folder" }),
                    " Export content for manual repository work"),
                React.createElement("p", null, "Export canonical pack folders with stable IDs, local edits and attachments. All exported packs are deliberately marked private. Remarks, flags, archived status and reading state belong in your separate workspace backup."),
                React.createElement("button", { disabled: !!busy, onClick: () => action('Exporting private content workspace...', async () => { const result = await exportRepositoryWorkspace(compose(built, store.state), store.state, assets.asset); download(result.bytes, 'knowledge-atlas-content-workspace.private.zip'); notify(`Exported ${result.pageCount} pages in ${result.packCount} private packs.`); }) }, "Export private content workspace")),
            React.createElement("section", { className: "settings-section" },
                React.createElement("h3", null,
                    React.createElement(Icon, { name: "pdf" }),
                    "Export private PDF library"),
                React.createElement("p", null, "Download only private PDF binaries and metadata as a standard Atlas library ZIP. No publication, credentials or repository fetch. Public demo PDFs, note bodies and personal state are excluded; keep a complete backup separately."),
                React.createElement(Field, { label: "PDF library pack ID" },
                    React.createElement("input", { value: pdfExportId, onChange: e => setPdfExportId(e.target.value) })),
                React.createElement(Field, { label: "PDF library version" },
                    React.createElement("input", { value: pdfExportVersion, onChange: e => setPdfExportVersion(e.target.value) })),
                React.createElement("p", { className: "secondary" }, "For a fresh workspace or reviewed source-ownership migration. Reuse this ID and advance the version for changes; conflicting existing IDs are never silently overwritten."),
                React.createElement("button", { disabled: !!busy, onClick: () => action('Preparing private PDF library...', async () => { await store.flush(); const result = await exportPrivatePdfLibrary(compose(built, store.state), assets.asset, { id: pdfExportId, version: pdfExportVersion }); download(result.bytes, 'atlasnote-private-pdf-library.zip'); notify(`Exported ${result.documentCount} private PDF document(s). Nothing was uploaded.`); }) }, "Download private PDF library ZIP")),
            React.createElement("section", { className: "settings-section" },
                React.createElement("h3", null, "Appearance & storage"),
                React.createElement(Field, { label: "Theme" },
                    React.createElement("select", { "aria-label": "Theme", value: store.state.personal.session.theme, onChange: e => { document.dispatchEvent(new Event('atlas:before-reader-change')); store.personal(p => { p.session.theme = e.target.value; }); } }, Object.entries(THEME_LABELS).map(([key, value]) => React.createElement("option", { key: key, value: key }, value)))),
                React.createElement("label", { className: "inline-check" },
                    React.createElement("input", { type: "checkbox", checked: store.state.personal.session.showFlags, onChange: e => store.personal(p => { p.session.showFlags = e.target.checked; }) }),
                    "Show learning flags"),
                React.createElement(Field, { label: "Reading text size" },
                    React.createElement("input", { type: "range", min: "14", max: "22", step: "1", value: store.state.personal.session.fontSize, onChange: e => { document.dispatchEvent(new Event('atlas:before-reader-change')); store.personal(p => { p.session.fontSize = Number(e.target.value); }); } })),
                React.createElement("p", null,
                    usage ? `${Math.round((usage.usage ?? 0) / 1024 / 1024 * 10) / 10} MB used of approximately ${Math.round((usage.quota ?? 0) / 1024 / 1024)} MB available.` : 'Storage is managed by this browser.',
                    " Clearing site data removes local changes."),
                React.createElement("button", { onClick: () => action('Requesting persistent storage...', async () => { const kept = await navigator.storage?.persist?.(); notify(kept ? 'Persistent storage permission granted. Backups are still recommended.' : 'Persistent storage was not granted. Keep regular backups.'); }) }, "Request persistent storage"),
                React.createElement("p", { className: "secondary" }, "No sign-in, telemetry, automatic external image fetches, or background synchronization."))),
        busy && React.createElement("div", { className: "busy-status", role: "status" }, busy),
        error && React.createElement("pre", { className: "error-message", role: "alert" }, error));
}
