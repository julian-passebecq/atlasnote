import React, { useEffect, useRef } from '../vendor/react.mjs';
import { IconButton } from './Icon.js';
export function Modal({ title, onClose, children, wide = false }) { const ref = useRef(null); useEffect(() => { const dialog = ref.current, before = document.activeElement; dialog.showModal(); const close = (e) => { e.preventDefault(); onClose(); }; dialog.addEventListener('cancel', close); return () => { dialog.removeEventListener('cancel', close); dialog.close(); before?.focus?.(); }; }, []); return React.createElement("dialog", { ref: ref, className: wide ? 'wide' : '', "aria-label": title },
    React.createElement("div", { className: "dialog-title" },
        React.createElement("h2", null, title),
        React.createElement(IconButton, { name: "close", label: "Close dialog", onClick: onClose })),
    React.createElement("div", { className: "dialog-body" }, children)); }
export function Field({ label, children }) { return React.createElement("label", { className: "field" },
    React.createElement("span", null, label),
    children); }
