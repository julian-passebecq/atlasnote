import React, { useState } from '../vendor/react.mjs';
import { Modal, Field } from './Modal.js';
import { Icon } from './Icon.js';
import { store } from '../storage/database.js';
import { uid, makeMarkdownPage, editPageLosslessly, applyOperation, locations } from '../core/workspace.js';
import { validateSchema, walkBlocks, validateRelations } from '../core/validation.mjs';
import { schemas } from '../app/load.js';
export function folderOptions(project, excluded) { const result = []; function walk(nodes, path) { for (const n of nodes) {
    if (n.id === excluded)
        continue;
    if (n.children) {
        result.push({ id: n.id, title: [...path, n.title].join(' / ') });
        walk(n.children, [...path, n.title]);
    }
} } if (project)
    walk(project.nodes, []); return result; }
export function CreateDialog({ kind, project, folder, catalogue: c, onClose, onOpen, notify }) {
    const [title, setTitle] = useState(''), [text, setText] = useState(''), [pid, setPid] = useState(project?.id ?? c.projects[0]?.id ?? ''), [parent, setParent] = useState(folder?.id ?? ''), [icon, setIcon] = useState('book'), [busy, setBusy] = useState(false);
    async function save(e) { e.preventDefault(); if (!title.trim())
        return; setBusy(true); try {
        const id = uid(kind === 'project' ? 'project.local' : 'node.local');
        let page;
        await store.overlays(o => { if (kind === 'project')
            o.projects.push({ id, title: title.trim(), icon, description: text, nodes: [] });
        else {
            const p = c.projects.find((p) => p.id === pid);
            if (!p)
                throw Error('Select a notebook first');
            if (kind === 'page') {
                page = makeMarkdownPage(title.trim(), text);
                o.pages[page.id] = { page };
            }
            const op = { kind: 'add', nodeId: id, projectId: pid, parentId: parent || undefined, node: kind === 'page' ? { id, title: title.trim(), pageId: page.id } : { id, title: title.trim(), children: [] } };
            applyOperation(structuredClone(c.projects), op);
            o.operations.push(op);
        } });
        store.personal(p => { for (const branch of [kind === 'project' ? id : pid, parent].filter(Boolean))
            if (!p.session.expanded.includes(branch))
                p.session.expanded.push(branch); });
        onClose();
        if (page)
            onOpen(page.id);
        notify(kind === 'project' ? 'Notebook created locally.' : kind === 'page' ? 'Page created locally.' : 'Folder created locally.');
    }
    catch (e) {
        notify(e.message, true);
    }
    finally {
        setBusy(false);
    } }
    return React.createElement(Modal, { title: 'New ' + (kind === 'project' ? 'notebook' : kind), onClose: onClose },
        React.createElement("form", { onSubmit: save },
            React.createElement(Field, { label: "Title" },
                React.createElement("input", { autoFocus: true, required: true, maxLength: 200, value: title, onChange: e => setTitle(e.target.value) })),
            kind === 'project' ? React.createElement(Field, { label: "Notebook icon" },
                React.createElement("select", { value: icon, onChange: e => setIcon(e.target.value) }, ['book', 'database', 'cloud', 'language', 'code', 'folder'].map(n => React.createElement("option", { key: n }, n)))) : React.createElement(React.Fragment, null,
                React.createElement(Field, { label: "Notebook" },
                    React.createElement("select", { value: pid, onChange: e => { setPid(e.target.value); setParent(''); } }, c.projects.map((p) => React.createElement("option", { key: p.id, value: p.id }, p.title)))),
                React.createElement(Field, { label: "Inside folder" },
                    React.createElement("select", { value: parent, onChange: e => setParent(e.target.value) },
                        React.createElement("option", { value: "" }, "Notebook root"),
                        folderOptions(c.projects.find((p) => p.id === pid)).map(o => React.createElement("option", { value: o.id, key: o.id }, o.title))))),
            kind !== 'folder' && React.createElement(Field, { label: kind === 'project' ? 'Description' : 'Page content (Markdown)' },
                React.createElement("textarea", { rows: kind === 'project' ? 3 : 8, value: text, onChange: e => setText(e.target.value), placeholder: kind === 'page' ? 'Write a thought, a reference, or a [[page.id|linked page]]...' : '' })),
            React.createElement("p", { className: "secondary" }, "Saved only in this browser. Export a backup to keep a portable copy."),
            React.createElement("div", { className: "dialog-actions" },
                React.createElement("button", { type: "button", onClick: onClose }, "Cancel"),
                React.createElement("button", { className: "primary", disabled: busy || !title.trim() || kind !== 'project' && !pid },
                    "Create ",
                    kind === 'project' ? 'notebook' : kind))));
}
export function ManageDialog({ item, catalogue: c, onClose, onCreate, onEdit, notify }) {
    const { project, node } = item, [title, setTitle] = useState(node?.title ?? project.title), [icon, setIcon] = useState(project.icon), [description, setDescription] = useState(project.description), [pid, setPid] = useState(project.id), [parent, setParent] = useState(''), [group, setGroup] = useState(c.groups.find((g) => g.projectIds.includes(project.id))?.id ?? '');
    const isProject = !node;
    async function run(fn) { try {
        await store.overlays(fn);
        notify('Changes saved locally.');
        onClose();
    }
    catch (e) {
        notify(e.message, true);
    } }
    function rename(e) { e.preventDefault(); run((o) => { if (isProject) {
        o.projectPrefs[project.id] = { ...o.projectPrefs[project.id], title: title.trim(), icon, description };
        o.groups = structuredClone(o.groups ?? c.groups);
        o.groups.forEach((g) => { g.projectIds = g.projectIds.filter((id) => id !== project.id); if (g.id === group)
            g.projectIds.push(project.id); });
    }
    else {
        o.operations.push({ kind: 'rename', nodeId: node.id, title: title.trim() });
        if (node.pageId) {
            const p = c.pages.find((p) => p.id === node.pageId);
            if (p)
                o.pages[p.id] = { page: { ...structuredClone(p), title: title.trim() }, baseHash: o.pages[p.id]?.baseHash ?? c.packs.find((p) => p.manifest.id === c.owners[node.pageId])?.hash };
        }
    } }); }
    function move() { run((o) => { const op = { kind: 'move', nodeId: node.id, projectId: pid, parentId: parent || undefined }; applyOperation(structuredClone(c.projects), op); o.operations.push(op); }); }
    function order(delta) { run((o) => { if (isProject) {
        const ids = c.projects.map((p) => p.id), index = ids.indexOf(project.id), next = Math.min(ids.length - 1, Math.max(0, index + delta));
        [ids[index], ids[next]] = [ids[next], ids[index]];
        ids.forEach((id, i) => o.projectPrefs[id] = { ...o.projectPrefs[id], order: i });
    }
    else
        o.operations.push({ kind: 'order', nodeId: node.id, delta }); }); }
    return React.createElement(Modal, { title: 'Manage ' + (isProject ? 'notebook' : node.pageId ? 'page' : 'folder'), onClose: onClose },
        React.createElement("form", { onSubmit: rename },
            React.createElement(Field, { label: "Title" },
                React.createElement("input", { autoFocus: item.intent === 'rename', value: title, maxLength: 200, onChange: e => setTitle(e.target.value), required: true })),
            isProject && React.createElement(React.Fragment, null,
                React.createElement(Field, { label: "Icon" },
                    React.createElement("select", { value: icon, onChange: e => setIcon(e.target.value) }, ['book', 'database', 'cloud', 'language', 'code', 'folder'].map(n => React.createElement("option", { key: n }, n)))),
                React.createElement(Field, { label: "Description" },
                    React.createElement("textarea", { value: description, onChange: e => setDescription(e.target.value), rows: 2 })),
                React.createElement(Field, { label: "Sidebar group" },
                    React.createElement("select", { value: group, onChange: e => setGroup(e.target.value) },
                        React.createElement("option", { value: "" }, "Ungrouped"),
                        c.groups.map((g) => React.createElement("option", { key: g.id, value: g.id }, g.title))))),
            React.createElement("button", { className: "primary", disabled: !title.trim() }, "Save details")),
        React.createElement("hr", null),
        !isProject && node.pageId && React.createElement("button", { onClick: () => onEdit(node.pageId) },
            React.createElement(Icon, { name: "edit" }),
            " Edit page content"),
        (isProject || node.children) && React.createElement("div", { className: "button-row" },
            React.createElement("button", { onClick: () => onCreate('page', project, node) },
                React.createElement(Icon, { name: "plus" }),
                " Add page"),
            React.createElement("button", { onClick: () => onCreate('folder', project, node) },
                React.createElement(Icon, { name: "folder" }),
                " Add folder")),
        !isProject && React.createElement("details", { open: item.intent === 'move' || undefined },
            React.createElement("summary", null, "Move without changing IDs or links"),
            React.createElement(Field, { label: "Destination notebook" },
                React.createElement("select", { "aria-label": "Destination notebook", value: pid, onChange: e => { setPid(e.target.value); setParent(''); } }, c.projects.map((p) => React.createElement("option", { key: p.id, value: p.id }, p.title)))),
            React.createElement(Field, { label: "Destination folder" },
                React.createElement("select", { "aria-label": "Destination folder", value: parent, onChange: e => setParent(e.target.value) },
                    React.createElement("option", { value: "" }, "Notebook root"),
                    folderOptions(c.projects.find((p) => p.id === pid), node.id).map(o => React.createElement("option", { key: o.id, value: o.id }, o.title)))),
            React.createElement("button", { onClick: move }, "Move here")),
        React.createElement("div", { className: "button-row" },
            React.createElement("button", { onClick: () => order(-1) }, "Move up"),
            React.createElement("button", { onClick: () => order(1) }, "Move down"),
            isProject && React.createElement("button", { onClick: () => run((o) => { o.projectPrefs[project.id] = { ...o.projectPrefs[project.id], hidden: !o.projectPrefs[project.id]?.hidden }; }) }, store.state.overlays.projectPrefs[project.id]?.hidden ? 'Show in sidebar' : 'Hide from sidebar')),
        React.createElement("div", { className: "archive-action" },
            React.createElement("p", null, "Archive hides the item without deleting its content or personal state. Restore it from Home."),
            React.createElement("button", { onClick: () => run((o) => { const id = node?.id ?? project.id; if (!o.archived.includes(id))
                    o.archived.push(id); }) },
                React.createElement(Icon, { name: "archive" }),
                " Archive ",
                isProject ? 'notebook' : 'item')),
        React.createElement("small", { className: "secondary" },
            "Stable ID: ",
            node?.id ?? project.id));
}
export function EditPageDialog({ page, catalogue: c, onClose, notify }) {
    const [title, setTitle] = useState(page.title), [summary, setSummary] = useState(page.summary), [advanced, setAdvanced] = useState(false), [json, setJson] = useState(JSON.stringify(page, null, 2)), [error, setError] = useState('');
    const [texts, setTexts] = useState(() => { const t = {}; walkBlocks(page.blocks, (b) => { if (b.type === 'markdown')
        t[b.id] = b.text; }); return t; });
    const [extra, setExtra] = useState(''), [tags, setTags] = useState(page.tags.join(', '));
    const localDoc = store.state.overlays.documents.find(d => d.pageId === page.id);
    const [language, setLanguage] = useState(localDoc?.language ?? 'unknown');
    async function save() { try {
        setError('');
        let edited = advanced ? JSON.parse(json) : editPageLosslessly(page, title.trim(), summary, texts);
        if (!advanced)
            edited.tags = [...new Set(tags.split(',').map((s) => s.trim()).filter(Boolean))];
        if (localDoc && !/^(?:[A-Za-z]{2,8}(?:-[A-Za-z0-9]{2,8})*|unknown|multi)$/.test(language))
            throw Error('Use a primary language code such as en, nb, fr or unknown.');
        if (!advanced && extra.trim())
            edited.blocks.push({ id: uid('block'), type: 'markdown', text: extra });
        if (edited.id !== page.id)
            throw Error('The page ID cannot be changed.');
        const s = await schemas();
        validateSchema({ schemaVersion: 2, title: 'Edited page', projects: [], pages: [edited], glossary: [], groups: [] }, s.v2, 'page');
        const activePages = c.pages.map((p) => p.id === page.id ? edited : p);
        validateRelations([{ manifest: { id: 'workspace', requires: [] }, pages: activePages, projects: c.projects, glossary: c.glossary, documents: c.documents }]);
        await store.overlays(o => { if (localDoc) {
            const d = o.documents.find(d => d.id === localDoc.id);
            if (d) {
                d.language = language;
                d.title = edited.title;
            }
        } o.pages[page.id] = { page: edited, baseHash: o.pages[page.id]?.baseHash ?? c.packs.find((p) => p.manifest.id === c.owners[page.id])?.hash }; const loc = locations(c).get(page.id); if (loc)
            o.operations.push({ kind: 'rename', nodeId: loc.nodeId, title: edited.title }); });
        notify('Page updated. Structured blocks and stable IDs are preserved.');
        onClose();
    }
    catch (e) {
        setError(e.message);
    } }
    return React.createElement(Modal, { title: "Edit page", onClose: onClose, wide: true },
        React.createElement("p", { className: "secondary" }, "Simple editing changes only the fields below. Bilingual pairs, questions, tables, diagrams and code blocks are retained. Use validated JSON for structured changes."),
        React.createElement("label", { className: "inline-check" },
            React.createElement("input", { type: "checkbox", checked: advanced, onChange: e => { if (e.target.checked)
                    setJson(JSON.stringify(editPageLosslessly(page, title, summary, texts), null, 2)); setAdvanced(e.target.checked); } }),
            " Advanced structured JSON"),
        advanced ? React.createElement(Field, { label: "Page JSON - all existing IDs must remain stable" },
            React.createElement("textarea", { className: "json-editor", rows: 20, value: json, onChange: e => setJson(e.target.value) })) : React.createElement(React.Fragment, null,
            React.createElement(Field, { label: "Page title" },
                React.createElement("input", { value: title, onChange: e => setTitle(e.target.value), maxLength: 240 })),
            React.createElement(Field, { label: "Summary" },
                React.createElement("textarea", { rows: 2, value: summary, onChange: e => setSummary(e.target.value) })),
            React.createElement(Field, { label: "Tags and facets (comma separated)" },
                React.createElement("input", { value: tags, onChange: e => setTags(e.target.value), placeholder: "doctype:cheatsheet, domain:data-engineering, tech:spark" })),
            localDoc && React.createElement(Field, { label: "Primary PDF language" },
                React.createElement("input", { value: language, onChange: e => setLanguage(e.target.value), placeholder: "en, nb, fr, unknown" })),
            Object.entries(texts).map(([id, text], i) => React.createElement(Field, { key: id, label: 'Text block ' + (i + 1) },
                React.createElement("textarea", { rows: Math.min(10, Math.max(3, text.split('\n').length + 1)), value: text, onChange: e => setTexts(t => ({ ...t, [id]: e.target.value })) }))),
            React.createElement(Field, { label: "Append a new text block (optional)" },
                React.createElement("textarea", { rows: 3, value: extra, onChange: e => setExtra(e.target.value) }))),
        error && React.createElement("pre", { className: "error-message", role: "alert" }, error),
        React.createElement("div", { className: "dialog-actions" },
            React.createElement("button", { onClick: onClose }, "Cancel"),
            React.createElement("button", { className: "primary", onClick: save }, "Save page locally")));
}
export function GroupsDialog({ catalogue: c, onClose, notify }) { const [groups, setGroups] = useState(structuredClone(c.groups)), [name, setName] = useState(''); async function save() { await store.overlays(o => { o.groups = groups; }); notify('Sidebar groups saved.'); onClose(); } return React.createElement(Modal, { title: "Sidebar groups", onClose: onClose },
    React.createElement("p", null, "Groups only organize notebooks. Removing a group never deletes its notebooks."),
    groups.map((g, i) => React.createElement("div", { className: "group-edit-row", key: g.id },
        React.createElement("input", { "aria-label": 'Group ' + (i + 1) + ' title', value: g.title, onChange: e => setGroups(gs => gs.map(x => x.id === g.id ? { ...x, title: e.target.value } : x)) }),
        React.createElement("button", { disabled: i === 0, onClick: () => setGroups(gs => { const n = [...gs]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; return n; }) }, "Up"),
        React.createElement("button", { onClick: () => setGroups(gs => gs.filter(x => x.id !== g.id)) }, "Ungroup"))),
    React.createElement("div", { className: "group-edit-row" },
        React.createElement("input", { placeholder: "New group name", "aria-label": "New group name", value: name, onChange: e => setName(e.target.value) }),
        React.createElement("button", { disabled: !name.trim(), onClick: () => { setGroups(gs => [...gs, { id: uid('group'), title: name.trim(), projectIds: [] }]); setName(''); } }, "Add")),
    React.createElement("p", { className: "secondary" }, "Assign notebooks to groups from each notebook's Manage menu."),
    React.createElement("div", { className: "dialog-actions" },
        React.createElement("button", { onClick: onClose }, "Cancel"),
        React.createElement("button", { className: "primary", onClick: save, disabled: groups.some(g => !g.title.trim()) }, "Save groups"))); }
