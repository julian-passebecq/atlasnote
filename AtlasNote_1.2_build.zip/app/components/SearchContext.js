import React, { useState, useMemo } from '../vendor/react.mjs';
import { Modal } from './Modal.js';
import { Icon, IconButton } from './Icon.js';
import { Inline } from '../reader/markdown.js';
import { searchCatalog, locations } from '../core/workspace.js';
import { pageLinks, walkBlocks } from '../core/validation.mjs';
import { store } from '../storage/database.js';
export function TermCard({ term: t, onOpen, catalogue: c }) { return React.createElement("details", { className: "term-card" },
    React.createElement("summary", null,
        t.label,
        t.translation && React.createElement("small", null, t.translation)),
    React.createElement("p", null,
        React.createElement(Inline, { text: t.definition })),
    t.example && React.createElement("div", { className: "term-example" },
        React.createElement("strong", null, "Example"),
        React.createElement("p", null,
            React.createElement(Inline, { text: t.example }))),
    React.createElement("div", { className: "term-pages" }, t.pageIds.map((id) => React.createElement("button", { className: "text-button", key: id, onClick: () => onOpen(id) },
        React.createElement(Icon, { name: "link", size: 13 }),
        c.pages.find((p) => p.id === id)?.title ?? id)))); }
export function SearchDialog({ catalogue: c, onClose, onOpen, initial = '' }) { const [query, setQuery] = useState(initial), [tab, setTab] = useState('all'), results = useMemo(() => searchCatalog(c, query), [c, query]), locs = useMemo(() => locations(c), [c]); return React.createElement(Modal, { title: "Search your knowledge", onClose: onClose, wide: true },
    React.createElement("form", { className: "search-form", onSubmit: e => { e.preventDefault(); if (results.pages[0])
            onOpen(results.pages[0].page.id, { blockId: results.pages[0].anchor }); } },
        React.createElement(Icon, { name: "search" }),
        React.createElement("input", { autoFocus: true, "aria-label": "Search all pages and glossary", placeholder: "A concept, code token, Norwegian word, or page title...", value: query, onChange: e => setQuery(e.target.value) }),
        React.createElement("kbd", null, "Enter")),
    React.createElement("div", { className: "dialog-tabs" }, ['all', 'pages', 'glossary'].map(t => React.createElement("button", { className: tab === t ? 'selected' : '', key: t, onClick: () => setTab(t) }, t === 'all' ? 'All results' : t === 'pages' ? `Pages (${results.pages.length})` : `Glossary (${results.terms.length})`))),
    React.createElement("div", { className: "search-results" }, !query.trim() ? React.createElement("div", { className: "empty-state" },
        React.createElement(Icon, { name: "search", size: 28 }),
        React.createElement("h3", null, "Follow an idea across notebooks"),
        React.createElement("p", null, "Search titles, text, code, folder paths, glossary definitions, translations and examples.")) : React.createElement(React.Fragment, null,
        tab !== 'glossary' && results.pages.slice(0, 60).map(({ page, anchor }) => React.createElement("div", { className: "search-result-row", key: page.id },
            React.createElement("button", { className: "search-result", onClick: e => onOpen(page.id, { blockId: anchor }, e.ctrlKey || e.metaKey), onAuxClick: e => { if (e.button === 1) {
                    e.preventDefault();
                    onOpen(page.id, { blockId: anchor }, true);
                } } },
                React.createElement(Icon, { name: "page" }),
                React.createElement("span", null,
                    React.createElement("strong", null, page.title),
                    React.createElement("small", null, locs.get(page.id)?.path.join(' / ')),
                    React.createElement("p", null, page.summary)),
                React.createElement(Icon, { name: "right", size: 16 })),
            React.createElement(IconButton, { name: "plus", label: 'Open ' + page.title + ' in new tab', onClick: () => onOpen(page.id, { blockId: anchor }, true) }))),
        tab !== 'pages' && results.terms.length > 0 && React.createElement("section", null,
            React.createElement("h3", null, "Glossary matches"),
            results.terms.slice(0, 80).map(t => React.createElement(TermCard, { key: t.id, term: t, catalogue: c, onOpen: onOpen }))),
        results.pages.length === 0 && results.terms.length === 0 && React.createElement("p", { className: "empty-state" }, "No matches. Try a shorter word or a code token."),
        results.pages.length > 60 && tab !== 'glossary' && React.createElement("p", { className: "secondary" },
            "Showing 60 of ",
            results.pages.length,
            " page matches. Refine the search.")))); }
export function ContextPanel({ catalogue: c, page, view, location, workspace: ws, onOpen, onJump, onClose, notify }) {
    const [tab, setTab] = useState('context'), [query, setQuery] = useState('');
    const doc = c.documents.find((d) => d.pageId === page?.id), physical = doc && location?.anchor?.pdfPage, remarkKey = page ? physical ? `${page.id}::pdf:${physical}@${doc.sha256 ?? 'external'}` : doc ? `${page.id}::document@${doc.sha256 ?? 'external'}` : page.id : '';
    const terms = useMemo(() => query.trim() ? searchCatalog(c, query).terms : c.glossary.filter((t) => page?.terms.includes(t.id) || t.pageIds.includes(page?.id)), [c, query, page]);
    const outline = [];
    if (page)
        walkBlocks(page.blocks, (b, parents) => { if (b.type === 'section')
            outline.push({ id: b.id, title: b.title, depth: parents.length }); });
    const backlinks = useMemo(() => page ? c.pages.filter((p) => p.id !== page.id && pageLinks(p).includes(page.id)) : [], [c, page]);
    const oldNotes = doc ? Object.entries(ws.personal.notes).filter(([key, n]) => n.pageId === page?.id && n.revision && n.revision !== doc.sha256) : [];
    return React.createElement("aside", { className: "context-panel", "aria-label": "Active page context" },
        React.createElement("div", { className: "context-heading" },
            React.createElement("strong", null, tab === 'remarks' ? 'Personal remarks' : tab === 'outline' ? 'On this page' : 'Context'),
            React.createElement(IconButton, { name: "context", label: "Collapse context panel", onClick: onClose })),
        React.createElement("div", { className: "context-tabs" }, ['context', 'outline', 'remarks'].map(t => React.createElement("button", { className: tab === t ? 'selected' : '', key: t, onClick: () => setTab(t) }, t[0].toUpperCase() + t.slice(1)))),
        page ? React.createElement("div", { className: "context-scroll" }, tab === 'context' ? React.createElement(React.Fragment, null,
            React.createElement("div", { className: "eyebrow context-section-label" },
                "GLOSSARY ",
                React.createElement("span", null, terms.length)),
            React.createElement("div", { className: "context-search" },
                React.createElement(Icon, { name: "search", size: 15 }),
                React.createElement("input", { "aria-label": "Search glossary", placeholder: "Find a term...", value: query, onChange: e => setQuery(e.target.value) }),
                query && React.createElement(IconButton, { name: "close", label: "Clear glossary search", onClick: () => setQuery('') })),
            terms.length ? terms.slice(0, 40).map((t) => React.createElement(TermCard, { key: t.id, term: t, catalogue: c, onOpen: onOpen })) : React.createElement("p", { className: "context-empty" }, "No glossary entries for this page. Search above to explore the full glossary."),
            terms.length > 40 && React.createElement("small", { className: "secondary" }, "Showing 40 terms. Refine the search."),
            React.createElement("div", { className: "eyebrow context-section-label" }, "RELATED PAGES"),
            page.related.length ? page.related.map((id) => React.createElement("button", { className: "context-link", key: id, onClick: () => onOpen(id) },
                React.createElement(Icon, { name: "page", size: 16 }),
                React.createElement("span", null, c.pages.find((p) => p.id === id)?.title ?? id),
                React.createElement(Icon, { name: "right", size: 13 }))) : React.createElement("p", { className: "context-empty" }, "No explicit related pages."),
            backlinks.length > 0 && React.createElement(React.Fragment, null,
                React.createElement("div", { className: "eyebrow context-section-label" }, "LINKED FROM"),
                backlinks.map((p) => React.createElement("button", { className: "context-link", key: p.id, onClick: () => onOpen(p.id) },
                    React.createElement(Icon, { name: "link", size: 15 }),
                    React.createElement("span", null, p.title)))),
            React.createElement("button", { className: "remark-shortcut", onClick: () => setTab('remarks') },
                React.createElement(Icon, { name: "edit", size: 16 }),
                ws.personal.notes[remarkKey]?.text ? 'Open your remarks' : 'Add a personal remark')) : tab === 'outline' ? React.createElement(React.Fragment, null,
            React.createElement("p", { className: "context-empty" }, "Jump to a section. A folded section opens before navigation."),
            outline.map(x => React.createElement("button", { key: x.id, className: "outline-link", style: { paddingLeft: 12 + x.depth * 12 }, onClick: () => onJump(x.id) }, x.title)),
            !outline.length && React.createElement("p", { className: "context-empty" }, "This page has no section headings.")) : React.createElement(React.Fragment, null,
            React.createElement("div", { className: "remarks-target" },
                React.createElement(Icon, { name: "lock", size: 15 }),
                React.createElement("strong", null, page.title),
                doc && React.createElement("small", null, physical ? 'Physical PDF page ' + physical : 'Document-level remark; browser preview position is not tracked.')),
            React.createElement("textarea", { className: "remarks-input", "aria-label": "Personal remarks", placeholder: "Your understanding, a question to revisit, a connection to another idea...", value: ws.personal.notes[remarkKey]?.text ?? '', onChange: e => { const text = e.target.value; const key = remarkKey, id = page.id, revision = doc?.sha256, anchor = physical ? { pdfPage: physical, pdfRevision: revision } : undefined; store.personal(p => { p.notes[key] = { text, pageId: id, updatedAt: Date.now(), revision, anchor }; }); } }),
            React.createElement("div", { className: "autosave-status" },
                store.error ? 'Storage needs attention' : store.saving ? 'Saving locally...' : 'Saved locally',
                React.createElement("span", null,
                    (ws.personal.notes[remarkKey]?.text ?? '').length,
                    " characters")),
            React.createElement("p", { className: "context-empty" }, "Remarks are separate from the source page. They are excluded from AI export and print unless you explicitly include them."),
            oldNotes.length > 0 && React.createElement("details", { className: "revision-warning" },
                React.createElement("summary", null,
                    "Remarks on another PDF revision (",
                    oldNotes.length,
                    ")"),
                React.createElement("p", null, "The document hash changed. These notes have not been silently reassigned to different physical pages."),
                oldNotes.map(([key, n]) => React.createElement("article", { key: key },
                    React.createElement("code", null, n.revision.slice(0, 12)),
                    React.createElement("p", null, n.text),
                    React.createElement("button", { onClick: () => { store.personal(p => { p.notes[remarkKey] = { ...n, revision: doc.sha256, anchor: physical ? { pdfPage: physical, pdfRevision: doc.sha256 } : undefined, updatedAt: Date.now() }; }); notify('Old remark copied to the current revision.'); } }, "Copy to current revision")))))) : React.createElement("div", { className: "empty-context" },
            React.createElement(Icon, { name: "book", size: 30 }),
            React.createElement("h3", null, "A little context goes a long way."),
            React.createElement("p", null, "Open a page to see its glossary, related notes and your own remarks.")));
}
