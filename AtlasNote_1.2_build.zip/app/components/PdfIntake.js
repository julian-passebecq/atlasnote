import React, { useState } from '../vendor/react.mjs';
import { emptyPdfMetadata, prepareLocalPdf, PDF_MAX_BYTES, PDF_TARGET_BYTES } from '../core/pdf-library.js';
import { store } from '../storage/database.js';
import { compose } from '../core/workspace.js';
import { assertSafeAsset, sha256 } from '../core/validation.mjs';
import { Field } from './Modal.js';
import { Icon } from './Icon.js';
import { folderOptions } from './EditDialogs.js';
export function PdfMetadataFields({ value, onChange }) {
    const field = (key, text) => React.createElement(Field, { label: text },
        React.createElement("input", { value: value[key], onChange: e => onChange({ ...value, [key]: e.target.value }) }));
    return React.createElement("div", { className: "pdf-metadata-fields" },
        React.createElement("div", { className: "field-wide" },
            React.createElement(Field, { label: "Document title" },
                React.createElement("input", { value: value.title, maxLength: 240, onChange: e => onChange({ ...value, title: e.target.value }) })),
            React.createElement(Field, { label: "PDF summary" },
                React.createElement("textarea", { rows: 2, value: value.summary, onChange: e => onChange({ ...value, summary: e.target.value }) }))),
        React.createElement(Field, { label: "Primary language" },
            React.createElement("select", { "aria-label": "Primary language", value: value.language, onChange: e => onChange({ ...value, language: e.target.value }) },
                React.createElement("option", { value: "" }, "Unknown / not specified"),
                [['en', 'English'], ['no', 'Norwegian'], ['nb', 'Norwegian Bokmal'], ['fr', 'French'], ['de', 'German'], ['es', 'Spanish'], ['multi', 'Multilingual']].map(([key, label]) => React.createElement("option", { key: key, value: key }, label)))),
        React.createElement(Field, { label: "Document type" },
            React.createElement("select", { "aria-label": "Document type", value: value.documentType, onChange: e => onChange({ ...value, documentType: e.target.value }) }, ['reference', 'cheatsheet', 'guide', 'slides', 'article', 'whitepaper', 'certification', 'diagram', 'other'].map(v => React.createElement("option", { key: v }, v)))),
        field('domains', 'Domains (comma separated)'),
        field('technologies', 'Technologies (comma separated)'),
        React.createElement(Field, { label: "Level" },
            React.createElement("select", { "aria-label": "Level", value: value.level, onChange: e => onChange({ ...value, level: e.target.value }) }, ['reference', 'overview', 'fundamentals', 'intermediate', 'advanced'].map(v => React.createElement("option", { key: v }, v)))),
        React.createElement(Field, { label: "Source channel" },
            React.createElement("select", { "aria-label": "Source channel", value: value.source, onChange: e => onChange({ ...value, source: e.target.value }) }, ['other', 'linkedin', 'vendor', 'web', 'personal'].map(v => React.createElement("option", { key: v }, v)))),
        React.createElement("div", { className: "field-wide" }, field('sourceUrl', 'Original source URL (optional)')),
        field('author', 'Author / creator (only if known)'),
        field('publisher', 'Publisher / company (only if known)'),
        React.createElement("div", { className: "field-wide" }, field('attribution', 'Attribution (optional)')),
        React.createElement(Field, { label: "Rights status" },
            React.createElement("select", { "aria-label": "Rights status", value: value.rights, onChange: e => onChange({ ...value, rights: e.target.value }) },
                React.createElement("option", { value: "reference-only" }, "Reference-only (private)"),
                React.createElement("option", { value: "unreviewed" }, "Unreviewed (private)"))),
        React.createElement(Field, { label: "Known page count (optional)" },
            React.createElement("input", { type: "number", min: "1", max: "100000", value: value.pageCount, onChange: e => onChange({ ...value, pageCount: e.target.value }) })));
}
export function PdfIntake({ built, catalogue: c, initialProject, initialFolder, onOpen, onClose, notify, disabled }) {
    const [file, setFile] = useState(null), [meta, setMeta] = useState(emptyPdfMetadata), [pid, setPid] = useState(initialProject ?? c.projects[0]?.id ?? ''), [parent, setParent] = useState(initialFolder ?? ''), [newFolder, setNewFolder] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState(''), [duplicate, setDuplicate] = useState(null);
    async function read(file) { setBusy(true); setError(''); setDuplicate(null); setFile(null); try {
        if (file.size > PDF_MAX_BYTES)
            throw Error('PDF exceeds the unchanged 20 MiB asset limit. Prepare it offline or keep it as an external reference.');
        const bytes = new Uint8Array(await file.arrayBuffer());
        assertSafeAsset('local.pdf', bytes, 'application/pdf');
        const hash = await sha256(bytes), found = compose(built, store.state).documents.find(d => d.sha256 === hash);
        if (found) {
            setDuplicate(found);
            return;
        }
        setFile({ bytes, hash });
        setMeta({ ...emptyPdfMetadata(), title: file.name.replace(/\.pdf$/i, '').slice(0, 240) });
    }
    catch (e) {
        setError(e.message);
    }
    finally {
        setBusy(false);
    } }
    async function commit() { setBusy(true); setError(''); try {
        await store.flush();
        const result = await prepareLocalPdf(compose(built, store.state), store.state, file.bytes, meta, pid, parent, newFolder);
        if (result.duplicate) {
            setDuplicate(result.duplicate);
            setFile(null);
            return;
        }
        await store.importPacks([], [result.asset], result.overlays);
        store.personal(p => { for (const id of [pid, parent, result.parentId].filter(Boolean))
            if (!p.session.expanded.includes(id))
                p.session.expanded.push(id); });
        onClose();
        onOpen(result.page.id);
        notify('Private PDF imported with its exact original bytes and one canonical tree placement.');
    }
    catch (e) {
        setError(e.message);
    }
    finally {
        setBusy(false);
    } }
    return React.createElement("section", { className: "settings-section pdf-intake" },
        React.createElement("h3", null,
            React.createElement(Icon, { name: "pdf" }),
            "Add a local PDF"),
        React.createElement("p", null, "Private on this device. The original bytes are kept unchanged. Publicly viewable material, including LinkedIn PDFs, is not automatically redistributable."),
        React.createElement("label", { className: "file-picker" },
            "Choose PDF",
            React.createElement("input", { "aria-label": "Import local PDF", type: "file", accept: ".pdf,application/pdf", disabled: disabled || busy, onChange: e => { const f = e.target.files?.[0]; if (f)
                    read(f); e.target.value = ''; } })),
        duplicate && React.createElement("div", { className: "pdf-duplicate", role: "status" },
            React.createElement("strong", null, "This PDF is already in your library"),
            React.createElement("p", null,
                duplicate.title,
                " has the same SHA-256. Reuse or move the existing item; no duplicate document or binary was created."),
            React.createElement("button", { onClick: () => { onClose(); onOpen(duplicate.pageId); } }, "Open existing PDF")),
        file && React.createElement("div", { className: "import-preview" },
            React.createElement(Field, { label: "Notebook" },
                React.createElement("select", { "aria-label": "Notebook", value: pid, onChange: e => { setPid(e.target.value); setParent(''); } }, c.projects.map((p) => React.createElement("option", { key: p.id, value: p.id }, p.title)))),
            React.createElement(Field, { label: "Inside folder" },
                React.createElement("select", { "aria-label": "Inside folder", value: parent, onChange: e => setParent(e.target.value) },
                    React.createElement("option", { value: "" }, "Notebook root"),
                    folderOptions(c.projects.find((p) => p.id === pid)).map(f => React.createElement("option", { key: f.id, value: f.id }, f.title)))),
            React.createElement(Field, { label: "New folder inside this location (optional)" },
                React.createElement("input", { value: newFolder, maxLength: 200, onChange: e => setNewFolder(e.target.value) })),
            React.createElement(PdfMetadataFields, { value: meta, onChange: setMeta }),
            React.createElement("p", { className: "secondary" }, "Leave unknown metadata blank. The optional page count is supplied by you, not guessed by the browser preview."),
            React.createElement("small", null,
                file.bytes.length.toLocaleString(),
                " bytes / SHA-256 ",
                file.hash),
            file.bytes.length > PDF_TARGET_BYTES && React.createElement("p", { className: "size-warning" }, "Above the 12 MiB operational target. Consider the offline preparation utility. The 20 MiB hard limit is unchanged."),
            React.createElement("div", { className: "button-row" },
                React.createElement("button", { onClick: () => setFile(null), disabled: busy }, "Cancel PDF"),
                React.createElement("button", { className: "primary", onClick: commit, disabled: disabled || busy || !meta.title.trim() || !pid }, "Import PDF locally"))),
        busy && React.createElement("p", { role: "status" }, "Checking and saving private PDF..."),
        error && React.createElement("p", { className: "error-message", role: "alert" }, error));
}
