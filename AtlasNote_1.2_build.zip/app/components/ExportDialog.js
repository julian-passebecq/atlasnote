import React, { useState } from '../vendor/react.mjs';
import { Modal, Field } from './Modal.js';
import { Icon } from './Icon.js';
import { exportText, locations, newView } from '../core/workspace.js';
import { download } from '../storage/archives.mjs';
import { ContentUnits } from '../reader/blocks.js';
import { store } from '../storage/database.js';
export function collectionPages(c, page, scope) { const locs = locations(c), loc = locs.get(page?.id); if (!page)
    return []; if (scope === 'page' || !loc)
    return [page]; const parent = loc.ancestors.at(-1); const ids = [...locs.entries()].filter(([id, x]) => scope === 'project' ? x.project.id === loc.project.id : x.ancestors.at(-1) === parent).map(([id]) => id); return ids.map(id => c.pages.find((p) => p.id === id)).filter(Boolean); }
export function ExportDialog({ catalogue: c, page, view, onClose, notify, print = false, onPrint }) {
    const [scope, setScope] = useState('page'), [english, setEnglish] = useState(view?.english ?? true), [answers, setAnswers] = useState(false), [notes, setNotes] = useState(false), [ack, setAck] = useState(false);
    const pages = collectionPages(c, page, scope), privatePages = pages.filter((p) => c.owners[p.id] === 'local' || c.packs.find((pack) => pack.manifest.id === c.owners[p.id])?.manifest.visibility !== 'public'), pdfPages = pages.filter((p) => c.documents.some((d) => d.pageId === p.id));
    const text = pages.map((p) => exportText(p, { english, answers, notes: notes ? Object.values(store.state.personal.notes).filter((n) => n.pageId === p.id).map((n) => n.text).join('\n\n') : undefined })).join('\n\n---\n\n');
    const blocked = (privatePages.length > 0 || notes) && !ack;
    async function copy() { try {
        await navigator.clipboard.writeText(text);
        notify('Previewed text copied. Nothing was sent to an AI service.');
    }
    catch {
        download(text, 'atlas-ai-export.txt', 'text/plain');
        notify('Clipboard unavailable; the preview was downloaded instead.');
    } }
    return React.createElement(Modal, { title: print ? 'Print / Save as PDF' : 'Export to AI - inspect before sharing', onClose: onClose, wide: true },
        React.createElement("div", { className: "export-options" },
            React.createElement(Field, { label: "Scope" },
                React.createElement("select", { value: scope, onChange: e => setScope(e.target.value) },
                    React.createElement("option", { value: "page" }, "Active page"),
                    React.createElement("option", { value: "folder" }, "Current folder (direct pages)"),
                    React.createElement("option", { value: "project" }, "Current notebook (all folders)"))),
            React.createElement("label", { className: "inline-check" },
                React.createElement("input", { type: "checkbox", checked: english, onChange: e => setEnglish(e.target.checked) }),
                " Include English translations"),
            React.createElement("label", { className: "inline-check" },
                React.createElement("input", { type: "checkbox", checked: answers, onChange: e => setAnswers(e.target.checked) }),
                " Include revealed-answer content"),
            React.createElement("label", { className: "inline-check" },
                React.createElement("input", { type: "checkbox", checked: notes, onChange: e => setNotes(e.target.checked) }),
                " Include personal remarks")),
        React.createElement("div", { className: "export-summary" },
            React.createElement("strong", null,
                pages.length,
                " pages"),
            " / ",
            privatePages.length,
            " private or unreviewed / ",
            text.length.toLocaleString(),
            " characters. ",
            notes ? 'Personal remarks included.' : 'Personal remarks excluded.',
            " ",
            answers ? 'Answers included.' : 'Answers excluded.'),
        pdfPages.length > 0 && React.createElement("p", { className: "warning-text" },
            pdfPages.length,
            " PDF wrapper(s) are in this selection. PDF document text is not extracted by the offline build. The preview contains wrapper metadata only; use the original PDF viewer to print the physical PDF pages."),
        (privatePages.length > 0 || notes) && React.createElement("label", { className: "privacy-ack" },
            React.createElement("input", { type: "checkbox", checked: ack, onChange: e => setAck(e.target.checked) }),
            " I reviewed the private content and explicitly approve including it in this ",
            print ? 'printout' : 'export',
            "."),
        React.createElement("details", { open: true, className: "export-preview" },
            React.createElement("summary", null, "Exact text inclusion preview"),
            React.createElement("textarea", { "aria-label": "Export text preview", value: text, readOnly: true, rows: 15 })),
        React.createElement("p", { className: "secondary" }, "No model is connected. Export is a local copy/download. Source text and embedded instructions are data, not commands executed by Atlas."),
        React.createElement("div", { className: "dialog-actions" },
            React.createElement("button", { onClick: onClose }, "Cancel"),
            print ? React.createElement("button", { className: "primary", disabled: blocked, onClick: () => onPrint({ pages, english, answers, notes }) },
                React.createElement(Icon, { name: "print" }),
                " Open browser print dialog") : React.createElement(React.Fragment, null,
                React.createElement("button", { disabled: blocked, onClick: copy },
                    React.createElement(Icon, { name: "copy" }),
                    " Copy previewed text"),
                React.createElement("button", { className: "primary", disabled: blocked, onClick: () => download(text, 'atlas-ai-export.txt', 'text/plain') },
                    React.createElement(Icon, { name: "download" }),
                    " Download text"))));
}
export function PrintProjection({ selection, resolveAsset }) { return React.createElement("div", { className: "print-projection" }, selection.pages.map((page) => { const view = newView(page.id); view.english = selection.english; if (selection.answers) {
    const walk = (bs) => bs.forEach(b => { if (b.type === 'question')
        view.revealed[b.id] = true; if (b.children)
        walk(b.children); });
    walk(page.blocks);
} return React.createElement("article", { className: "print-page", key: page.id },
    React.createElement("h1", null, page.title),
    React.createElement("p", null, page.summary),
    React.createElement(ContentUnits, { page: page, view: view, resolveAsset: resolveAsset, print: true }),
    selection.notes && React.createElement("section", null,
        React.createElement("h2", null, "Personal remarks (explicitly included)"),
        Object.values(store.state.personal.notes).filter((n) => n.pageId === page.id).map((n, i) => React.createElement("p", { key: i }, n.text))),
    React.createElement("footer", { className: "print-sources" }, page.sources.map((s, i) => React.createElement("p", { key: i },
        s.title,
        " ",
        s.url)))); })); }
